/*-----------------------------------------
File      : EX1801_.c
Purpose   : Graphics GLCD 128x64
Compiler  : AVR Studio/WinAVR
Target    : ATmega128 
------------------------------------------*/

//----------------------------------------:INCLUDE

#include <avr/io.h>         // AVR device-specific IO definitions
#include <compat/deprecated.h>  // Use sbi(), cbi() function
#include <avr/pgmspace.h>   // Program spaceString Utilities

#define F_CPU 16000000UL    // XTAL 16 MHz
#include <util/delay.h>     // header file implement simple delay loops

#include "Font5x7.dat"      // Eng Font 5x7

#include "LIB_GLCD.C"       // AVR GLCD Library
#include "LIB_GGLCD.C"      // AVR Graphics GLCD Library


int main(void)
{
  GLCD_init(ON);          // Init
  GLCD_fillScreen(0);     // Clear Screen

  GGLCD_text57(5,5, "Graphics GLCD 128x64");  // Display 
  GGLCD_line(1, 15, 127, 15, 1);              // Draw a line
  GGLCD_rect(10, 30, 30, 50, 1, 1);           // Draw a rectangle
  GGLCD_circle(50, 30, 10, 1, 1);             // Draw a circle
  GGLCD_rect(70, 30, 90, 50, 0, 1);           // Draw a rectangle
  GGLCD_circle(105, 30, 10, 0, 1);             // Draw a circle

  while(1)
    ;

	return 0;
}
