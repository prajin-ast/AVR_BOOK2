/*-----------------------------------------
File      : EX1001.c
Purpose   : Set/Clear and Toggle Bit
Compiler  : AVR Studio/WinAVR
Target    : ATmega128 
------------------------------------------*/

//----------------------------------------:INCLUDE

#include <avr/io.h>         // AVR device-specific IO definitions

#define F_CPU 8000000UL     // XTAL 8 MHz
#include <util/delay.h>     // header file implement simple delay loops


// Bit Manipulation
#define output_high(p, b)   (p) |= (1 << (b))
#define output_low(p, b)    (p) &= ~(1 << (b))
#define output_toggle(p,b)  (!(p&(1<<b)) ? (output_high(p,b)):(output_low(p,b)))

// Byte Manipulation
#define set_ddr_a(byte)     (DDRA = byte)
#define set_ddr_b(byte)     (DDRB = byte)

#define output_a(byte) 	    (PORTA = byte)
#define output_b(byte) 	    (PORTB = byte)


//----------------------------------------:FUNCTION

// delay miliseconds
void delay_ms(uint16_t i)
{
  for (;i > 0; i--)
    _delay_ms(1);
}

//----------------------------------------:MAIN

int main(void)
{
  set_ddr_a(0xFF);          // set PORTA output all
  set_ddr_b(0x01);          // set PORTB bit 0 output

  while (1) {               // loop forever            
    output_a(0xFF);         // set PORTA
    delay_ms(500);
    output_a(0);            // clear PORTA
    delay_ms(500);          // delay 0.5s

    output_high(PORTA,0);   // set PORTA bit 0 
    delay_ms(500);          // delay 0.5s
    output_low(PORTA,0);    // clear PORTA bit 0
    delay_ms(500);          // delay 0.5s

    output_toggle(PORTB,0); // toggle PORTB bit 0
    delay_ms(500);
  }

  return 0;
}
