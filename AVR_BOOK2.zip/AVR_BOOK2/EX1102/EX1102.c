/*-----------------------------------------
File      : EX1102.c
Purpose   : Input port
Compiler  : AVR Studio/WinAVR
Target    : ATmega128 
------------------------------------------*/

//----------------------------------------:INCLUDE

#include <avr/io.h>         // AVR device-specific IO definitions
#include <compat/deprecated.h>  // Use sbi(), cbi() function

#define F_CPU 16000000UL    // XTAL 16 MHz
#include <util/delay.h>     // header file implement simple delay loops


//----------------------------------------:MAIN

int main(void)
{      
  
  DDRF = (1<<PINF1)|(1<<PINF2); // Set PF1,PF2 output port

  while (1) {   

    if ((PINF&(1<<PINF0))==0)
    {
      sbi(PORTF,1);
      cbi(PORTF,2);
    } else {
      cbi(PORTF,1);
      sbi(PORTF,2);
    }
  }    

  return 0;
}
