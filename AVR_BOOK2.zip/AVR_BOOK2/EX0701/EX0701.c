/*-----------------------------------------
File      : EX0701.c
Purpose   : LCD Custom Character
Compiler  : AVR Studio/WinAVR
Target    : ATmega16 
------------------------------------------*/

//----------------------------------------:INCLUDE

#include <avr/io.h>             // AVR device-specific IO definitions
#include <compat/deprecated.h>  // Use sbi(), cbi() function

#define F_CPU 8000000UL         // XTAL 8 MHz
#include <util/delay.h>         // header file implement simple delay loops

#include "LIB_LCD.C"            // LCD Library 


//----------------------------------------:FUNCTION

// delay miliseconds
void delay_ms(uint16_t i)
{
    for (;i > 0; i--)
        _delay_ms(1);
}

// LCD_Custom
void LCD_Custom(void)
{
    unsigned char  i,j;
    unsigned char CGRAM=0x40;
    unsigned char MouthSmile[8][8] = {
        {0x0E,0x1F,0x15,0x1F,0x11,0x1F,0x0E,0x00},  // Mouth 0
        {0x0E,0x1B,0x1F,0x18,0x1F,0x1F,0x0E,0x00},  // Mouth 1
        {0x0E,0x1B,0x1C,0x18,0x1C,0x1F,0x0E,0x00},  // Mouth 2
        {0x0F,0x14,0x18,0x10,0x18,0x1C,0x0F,0x00},  // Mouth 3
        {0x0E,0x1B,0x1F,0x1C,0x1F,0x1F,0x0E,0x00},  // Mouth 4
        {0x00,0x0A,0x0A,0x00,0x11,0x0E,0x00,0x00},  // Smile 1
        {0x00,0x0A,0x0A,0x00,0x11,0x0E,0x06,0x00},  // Smile 2
        {0x0E,0x1B,0x1F,0x0E,0x04,0x1F,0x0E,0x04},  // Flower
    };

    for (i=0;i<8;i++) {
        for (j=0;j<8;j++) {
            LCD_Command(CGRAM); // Custom character RAM
            LCD_PutChar(MouthSmile[i][j]);
            CGRAM = CGRAM+1;    // Next address CGRAM
        }
    }

    return;
}

//----------------------------------------:MAIN

int main(void)
{    
    int i;

    Init_LCD();       // Init LCD Display

    LCD_Custom();     // Creating custom lcd characters

    LCD_GotoXY(1,1);
    LCD_PutStr(0,"Custom LCD Test!");
    
    // Write Flower
    LCD_GotoXY(9,2);            // Position x/y
    LCD_PutChar('<');           // Write "<"
    for (i=10;i<=15;i++) {    
        LCD_GotoXY(i,2);        // Position x/y
        LCD_PutChar(7);         // Write Flower
    }
    LCD_GotoXY(16,2);           // Position x/y
    LCD_PutChar('>');           // Write ">"

    // Animation Mouth&Smile
    while (1) {                 // Loop forever   
        LCD_GotoXY(5,2);        // Position x/y
        LCD_PutChar(7);         // Write Flower

        for (i=0;i<7;i++) {     // show animation
            LCD_GotoXY(i+1,2);  // Position x/y
            LCD_PutChar(i);     // Write LCD Customer
            delay_ms(500);      // Delay 0.5s
            LCD_GotoXY(i+1,2);  // Position x/y
            LCD_PutStr(0," ");  // Clear
        }             
    }

    return 0;
}
