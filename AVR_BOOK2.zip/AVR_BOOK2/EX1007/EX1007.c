/*-----------------------------------------
File      : EX1007.c
Purpose   : UART0 Module
Compiler  : AVR Studio/WinAVR
Target    : ATmega128 
------------------------------------------*/

//----------------------------------------:INCLUDE

#include <avr/io.h>   // AVR device-specific IO definitions


//----------------------------------------:MAIN

int main(void)
{
  struct {
    char ch1:3;
    char ch2:5;
  }ch;

  ch.ch1 = 5;
  ch.ch2 = 30;

  while (1);          // loop forever            
    
  return 0;
}
