/*-----------------------------------------
File      : EX1501.c
Purpose   : Super Loops
Compiler  : AVR Studio/WinAVR
Target    : ATmega128 
------------------------------------------*/

//----------------------------------------:INCLUDE

#include <avr/io.h>         // AVR device-specific IO definitions
#include <avr/interrupt.h>	// Interrupt Service routine
#include <compat/deprecated.h>  // Use sbi(), cbi() function

#define F_CPU 16000000UL    // XTAL 16 MHz
#include <util/delay.h>     // header file implement simple delay loops

// Bit Manipulation
#define output_high(p, b)   (p) |= (1 << (b))
#define output_low(p, b)    (p) &= ~(1 << (b))
#define output_toggle(p,b)	(!(p&(1<<b)) ? (output_high(p,b)):(output_low(p,b)))


//----------------------------------------:FUNCTION

// Task 1
void Task_1()
{
  unsigned int Tick=10;

  for (;Tick>0;Tick--) {
    output_toggle(PORTA,0);
    _delay_ms(100);
    }
}

// Task 2
void Task_2()
{
  unsigned int Tick=10;

  for (;Tick>0;Tick--) {
    output_toggle(PORTA,1);
    _delay_ms(100);
  } 
}

// Task 3
void Task_3()
{
  unsigned int Tick=10;

  for (;Tick>0;Tick--) {
    output_toggle(PORTA,2);
    _delay_ms(100);
  } 
}

//----------------------------------------:MAIN

int main(void)
{  
  DDRA = 0xFF;        // Set output PORTA

  while (1) {
    Task_1();
    Task_2();
    Task_3();            
  }
  
  return 0;
}
