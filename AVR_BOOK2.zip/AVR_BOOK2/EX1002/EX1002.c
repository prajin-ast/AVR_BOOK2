/*-----------------------------------------
File      : EX1002.c
Purpose   : Shift bit Operator
Compiler  : AVR Studio/WinAVR
Target    : ATmega128 
------------------------------------------*/

//----------------------------------------:INCLUDE

#include <avr/io.h>       // AVR device-specific IO definitions

#define F_CPU 8000000UL   // XTAL 8 MHz
#include <util/delay.h>   // header file implement simple delay loops

#include "LIB_PORT.C"     // PORT Library


//----------------------------------------:FUNCTION

// delay miliseconds
void delay_ms(uint16_t i)
{
  for (;i > 0; i--)
    _delay_ms(1);
}

//----------------------------------------:MAIN

int main(void)
{
  uint8_t n = 0x01;
  uint8_t i;

  set_ddr_a(0xFF);            // set porta output all

  while (1) {                 // loop forever            
    for (i=0;i<7;i++) {
      output_a(n);
      n = n << 1;         // shift left
      delay_ms(500);      // delay 0.5s
    }

    for (i=0;i<7;i++) {
      output_a(n);
      n = n >> 1;         // shift right
      delay_ms(500);      // delay 0.5s
    }
  }

    return 0;
}
