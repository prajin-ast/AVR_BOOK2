/*-----------------------------------------
File      : EX1004.c
Purpose   : Swap Byte&Word
Compiler  : AVR Studio/WinAVR
Target    : ATmega128 
------------------------------------------*/

//----------------------------------------:INCLUDE

#include <avr/io.h>         // AVR device-specific IO definitions

#define F_CPU 8000000UL     // XTAL 8 MHz
#include <util/delay.h>     // header file implement simple delay loops

#include "LIB_PORT.C"     // PORT Library


//----------------------------------------:FUNCTION

// delay miliseconds
void delay_ms(uint16_t i)
{
  for (;i > 0; i--)
    _delay_ms(1);
}

// swap byte
uint8_t swap_byte(uint8_t *x)
{
  *x = (*x<<4) | (*x>>4);

  return (*x);                         
}

// swap word
uint16_t swap_word(uint16_t *x)
{
  *x = (*x<<8) | (*x>>8);

  return (*x);                         
}


//----------------------------------------:MAIN

int main(void)
{
  uint8_t n = 0x0F;
  uint16_t m = 0x00FF;

  set_ddr_a(0xFF);    // set PORTA output all
  set_ddr_b(0xFF);    // set PORTB output all

  while (1) {         // loop forever            
    output_a(n);      // process swap byte        
    delay_ms(500);
    swap_byte(&n);
    output_a(n);
    delay_ms(500);
    output_b(n);
    delay_ms(500);
    swap_byte(&n);
    output_b(n);
    delay_ms(500);
        
    output_a(m);      // process swap word
    delay_ms(500);
    swap_word(&m);
    output_a(m);
    delay_ms(500);        
    output_b(m);
    delay_ms(500);
    swap_word(&m);
    output_b(m);
    delay_ms(500);
  }

    return 0;
}
