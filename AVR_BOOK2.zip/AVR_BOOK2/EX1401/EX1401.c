/*-----------------------------------------
File      : EX1401.c
Purpose   : UART0 Module
Compiler  : AVR Studio/WinAVR
Target    : ATmega128 
------------------------------------------*/

//----------------------------------------:INCLUDE

#include <avr/io.h>         // AVR device-specific IO definitions
#include <stdio.h>          // Standard I/O
#include <stdlib.h>         //Standard Library
#include <avr/interrupt.h>	// Interrupt Service routine

#define F_CPU 16000000UL    // XTAL 16 MHz
#include <util/delay.h>     // header file implement simple delay loops
 
#define RX_BUFSIZE  10      // Buffer RX
#include "Lib_UART128.c"    // Use Module USART ATmega128


//----------------------------------------:FUNCTION
 
// delay miliseconds
void delay_ms(uint16_t i)
{
  for (;i > 0; i--)
    _delay_ms(1);
}


//----------------------------------------:MAIN

int main(void)
{        
  char buf[RX_BUFSIZE];
  unsigned int i=0;

  USART_Init(0, 96);      // USART0 9,600 bps, 8:N:1 using a 16MHz crystal
 
  printf("\nUART Module : Serial Port Input/Output");

  while(1) {              // Loop forever                  
    if (i-- <= 0) {
        printf("\nInput Number for Countdown: ");
        gets(buf);              // Get string
        i = atoi(buf);          //  converts string to long integer 
        printf("\nCountdown..");
    }

    printf("\nNumber %d",i);
    delay_ms(500);     // Delay 0.5 sec
  }

  return 0;
}
