/**********************************************************************
* Workfile    : lib_UART128.c
* Purpose     : USART Library
* Copyright   : appsofttech co.,ltd.
* Author      : Prajin Palangsantikul
* Email       : prajin@appsofttech.com
* Compiler    : AVR Studio/WINAVR
* Target      : ATmega128
**********************************************************************/

/********************************************************** Includes */
#include <stdio.h>         // Standard Input/Output
#include <avr/io.h>        // AVR device-specific IO definitions
#include <avr/interrupt.h>	// Interrupt Service routine


/*********************************************** Prototype functions */
static int uart0_putchar(char c, FILE *stream);
static int uart1_putchar(char c, FILE *stream);
static int uart0_getchar(FILE *stream);
static int uart1_getchar(FILE *stream);

static FILE uart0_str = FDEV_SETUP_STREAM(uart0_putchar, uart0_getchar, 
                                         _FDEV_SETUP_RW);

static FILE uart1_str = FDEV_SETUP_STREAM(uart1_putchar, uart1_getchar, 
                                         _FDEV_SETUP_RW);

void Init_Serial(char uart, unsigned int baudrate);


/************************************************************** Note */
// use:
// 
// Init_Serial(unsigned int baudrate) Must be called before any other 
// function.
// 
// Stream I/O
// fprintf(&uart_str,"\f\nTime %d:%d:%d\n",hr,min,sec);
//
// printf("Hello, world!\n");
//
//

/***************************************************** USART putchar */
static int uart0_putchar(char c, FILE *stream)
{    
  if (c == '\a') {
    fputs("*ring*\n", stderr);
    return 0;
  }

  if (c == '\n')
    uart0_putchar('\r', stream);

  // wait for empty transmit buffer
  loop_until_bit_is_set(UCSR0A, UDRE0);

  // put data into buffer sends the data
  UDR0 = c;

  return 0;
}

static int uart1_putchar(char c, FILE *stream)
{    
  if (c == '\a') {
    fputs("*ring*\n", stderr);
    return 0;
  }

  if (c == '\n')
    uart1_putchar('\r', stream);

  // wait for empty transmit buffer
  loop_until_bit_is_set(UCSR1A, UDRE1);

  // put data into buffer sends the data
  UDR1 = c;

  return 0;
}

/***************************************************** USART getchar */
static int uart0_getchar(FILE *stream) {
  
    uint8_t c;
    char *cp, *cp2;
    static char b[RX_BUFSIZE];
    static char *rxp;

    if (rxp == 0)
    for (cp = b;;) {
	        
        loop_until_bit_is_set(UCSR0A, RXC0);
	        
        if (UCSR0A & _BV(FE0))    return _FDEV_EOF;
        if (UCSR0A & _BV(DOR0))   return _FDEV_ERR;

        c = UDR0;
        // behaviour similar to Unix stty ICRNL
        if (c == '\r')  c = '\n';
        if (c == '\n') {
            *cp = c;
            uart0_putchar(c, stream);
            rxp = b;
    	    break;
        } else if (c == '\t') c = ' ';

        if ((c >= (uint8_t)' ' && c <= (uint8_t)'\x7e') ||
            c >= (uint8_t)'\xa0') {

            if (cp == b + RX_BUFSIZE - 1)
                uart0_putchar('\a', stream);
            else {
                *cp++ = c;
                uart0_putchar(c, stream);
            }
            continue;
        }
    } // end for

    c = *rxp++;
    if (c == '\n')
        rxp = 0;

    return c;
}

static int uart1_getchar(FILE *stream) {
  
    uint8_t c;
    char *cp, *cp2;
    static char b[RX_BUFSIZE];
    static char *rxp;

    if (rxp == 0)
    for (cp = b;;) {
	        
        loop_until_bit_is_set(UCSR1A, RXC1);
	        
        if (UCSR1A & _BV(FE1))    return _FDEV_EOF;
        if (UCSR1A & _BV(DOR1))   return _FDEV_ERR;

        c = UDR1;

        // behaviour similar to Unix stty ICRNL
        if (c == '\r')  c = '\n';
        if (c == '\n') {
            *cp = c;
            uart1_putchar(c, stream);
            rxp = b;
    	    break;
        } else if (c == '\t') c = ' ';

        if ((c >= (uint8_t)' ' && c <= (uint8_t)'\x7e') ||
            c >= (uint8_t)'\xa0') {

            if (cp == b + RX_BUFSIZE - 1)
                uart1_putchar('\a', stream);
            else {
                *cp++ = c;
                uart1_putchar(c, stream);
            }
            continue;
        }

    } // end for

    c = *rxp++;
    if (c == '\n')
        rxp = 0;

    return c;
}

/*************************************************** Initialize UART */
// Initialize UART 0,1
static void USART_Init(char uart, unsigned int baud)
{
  switch (baud) {
    case 24:
      baud = 416;   // baudrate to 2,400 bps using a 16MHz crystal
    case 48:
      baud = 207;   // baudrate to 4,800 bps using a 16MHz crystal
    case 96:
      baud = 103;   // baudrate to 9,600 bps using a 16MHz crystal
    case 144:
      baud = 68;    // baudrate to 14.4K bps using a 16MHz crystal
    default:
      baud = 103;
  }

  if (!uart) {
    // Set baud rate
    UBRR0H = (unsigned char) (baud>>8);
    UBRR0L = (unsigned char) baud;
    
    // Enable receiver and tramsmitter
    UCSR0B = (1<<RXEN0)|(1<<TXEN0)|(0<<UCSZ02);

    // Set frame format: 8data, NoneParity, 1stop bit
    UCSR0C = (1<<USBS0)|(1<<UCSZ01)|(1<<UCSZ00);

    // Set address uart_str to stdout
    stdout = stdin = &uart0_str;     
  } else {
    // Set baud rate
    UBRR1H = (unsigned char) (baud>>8);
    UBRR1L = (unsigned char) baud;
    
    // Enable receiver and tramsmitter
    UCSR1B = (1<<RXEN1)|(1<<TXEN1)|(0<<UCSZ12);

    // Set frame format: 8data, NoneParity, 1stop bit
    UCSR1C = (1<<USBS1)|(1<<UCSZ11)|(1<<UCSZ10);

    // Set address uart_str to stdout
    stdout = stdin = &uart1_str;     
  }
}
