/*-----------------------------------------
File      : EX1604_CV0405.c
Purpose   : PORTA Input/Output
Compiler  : CodeVisionAVR
Target    : ATmega128 
------------------------------------------*/

//----------------------------------------:INCLUDE

#include <io.h>         // I/O registers definitions
#include <delay.h>      // Header file for Function Delay


//----------------------------------------:MAIN

int main(void)
{  
    DDRA=0x01;          // PA0 Output, PA1 input
    PORTA.0 = 0;        // Clear PA0
                
    while (1) {            // Loop forever
        if (PINA.1 == 0) { // Check input PA1   
            PORTA.0 = 1;   // Output High
        } else {
            PORTA.0 = 0;   // Output Low
        }
    }

    return 0;
}
