/*-----------------------------------------
File      : EX1604_CV0405.c
Purpose   : PORTA Input/Output
Compiler  : CodeVisionAVR
Target    : ATmega128
------------------------------------------*/

//----------------------------------------:INCLUDE

#include <io.h>         // I/O registers definitions
	#ifndef __SLEEP_DEFINED__
	#define __SLEEP_DEFINED__
	.EQU __se_bit=0x20
	.EQU __sm_mask=0x1C
	.EQU __sm_powerdown=0x10
	.EQU __sm_powersave=0x18
	.EQU __sm_standby=0x14
	.EQU __sm_ext_standby=0x1C
	.EQU __sm_adc_noise_red=0x08
	.SET power_ctrl_reg=mcucr
	#endif
#include <delay.h>      // Header file for Function Delay


//----------------------------------------:MAIN

int main(void)
{
    DDRA=0x01;          // PA0 Output, PA1 input
    PORTA.0 = 0;        // Clear PA0

    while (1) {            // Loop forever
        if (PINA.1 == 0) { // Check input PA1
            PORTA.0 = 1;   // Output High
        } else {
            PORTA.0 = 0;   // Output Low
        }
    }

    return 0;
}
