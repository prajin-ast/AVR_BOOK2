/*-----------------------------------------
File      : EX1006.c
Purpose   : Variables
Compiler  : AVR Studio/WinAVR
Target    : ATmega128 
------------------------------------------*/

//----------------------------------------:INCLUDE

#include <avr/io.h>     // AVR device-specific IO definitions


//----------------------------------------:MAIN

int main(void)
{
  char ch1;
  char ch2;
    
  ch1 = 5;
  ch2 = 30;    

  while (1);    // loop forever            
    
  return 0;
}
