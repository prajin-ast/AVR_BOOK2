/*-----------------------------------------
File      : EX0106.c
Purpose   : Sizeof function
Compiler  : AVR Studio/WinAVR
Target    : ATmega16 
------------------------------------------*/

//----------------------------------------:INCLUDE

#include <avr/io.h>         // AVR device-specific IO definitions
#include <stdio.h>          // Standard Library
#define F_CPU 8000000UL     // XTAL 8 MHz
#include <util/delay.h>     // header file implement simple delay loops

#include "LIB_UART.c"       // Include UART Library


//----------------------------------------:MAIN

int main(void)
{    
  char ch;
  int i;
  long l;
  float f;

  Init_Serial(96);        // Init Uart 9,600 bps using a 8MHz crystal
    
  printf("\nSizeof function test");
  printf("\nByte %d of character",sizeof(ch));
  printf("\nByte %d of integer",sizeof(i));
  printf("\nByte %d of long",sizeof(l));
  printf("\nByte %d of float",sizeof(f));

  while (1)               // loop nothing
    ;

  return 0;
}
