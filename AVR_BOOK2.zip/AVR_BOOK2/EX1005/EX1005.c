/*-----------------------------------------
File      : EX1005.c
Purpose   : Make 16 & 32 bit
Compiler  : AVR Studio/WinAVR
Target    : ATmega128 
------------------------------------------*/

//----------------------------------------:INCLUDE

#include <avr/io.h>         // AVR device-specific IO definitions


//----------------------------------------:FUNCTION

// make 16 bit
int16_t make_16bit(int8_t hi, int8_t lo)
{
  int16_t i=0;

  i = ((i|hi)<<8)|lo;

  return (i);
}

// make 32 bit
int32_t make_32bit(int16_t var1, int16_t var2)
{
  int32_t i=0;

  i = ((i|var1)<<16)|(i|var2);

  return (i);
}


//----------------------------------------:MAIN

int main(void)
{
  int16_t i16_1=0, i16_2=0;
  int32_t i32=0;
  int8_t i1=0x0F, i2=0x05, i3=0x0A;

  i16_1 = make_16bit(i1,i2);
  i16_2 = make_16bit(i2,i3);

  i32 = make_32bit(i16_1,i16_2);

  while (1);          // loop nothing
    
  return 0;
}
