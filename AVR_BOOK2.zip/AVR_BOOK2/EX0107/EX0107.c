/*-----------------------------------------
File      : EX0107.c
Purpose   : #if..#else..#endif Control Directives
Compiler  : AVR Studio/WinAVR
Target    : ATmega16 
------------------------------------------*/

//----------------------------------------:INCLUDE

#include <avr/io.h>     // AVR device-specific IO definitions

#define F_CPU 8000000UL     // XTAL 8 MHz    
#include <util/delay.h>     // header file implement simple delay loops

#define TEST    0           // Use TEST 1

#if (TEST==1)
  unsigned int n = 0x55;
#else
  unsigned int n = 0x0F;
#endif


//----------------------------------------:FUNCTION

// delay miliseconds
void delay_ms(uint16_t i)
{
  for (;i > 0; i--)
    _delay_ms(1);
}


//----------------------------------------:MAIN

int main(void)
{        
  DDRA = 0xff;      // set port output
  PORTA = 0;        // clear port

  while (1) {       // loop forever
    PORTA = n;
    n = ~n;         // one's complement
    delay_ms(500);  // 0.5s
  }

  return 0;
}
