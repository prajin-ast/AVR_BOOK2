/*-----------------------------------------
File      : EX1505.c
Purpose   : One Switch/Three LED RTOS Demo
Compiler  : AVR Studio/WinAVR
Target    : ATmega128 
------------------------------------------*/

//----------------------------------------:INCLUDE

// Scheduler include files.
#include "FreeRTOS.h"		
#include "task.h"

// Priority definitions for most of the tasks in the demo application.
// Some tasks just use the idle priority.
#define TASK1_PRIORITY		(tskIDLE_PRIORITY + 1)
#define TASK2_PRIORITY		(tskIDLE_PRIORITY + 2)
#define TASK3_PRIORITY		(tskIDLE_PRIORITY + 3)
#define TASK4_PRIORITY		(tskIDLE_PRIORITY + 4)

// Constant data for I/O
#define ALL_BITS_OUTPUT		((unsigned portCHAR) 0xff)
#define ALL_OUTPUTS_OFF		((unsigned portCHAR) 0x00)
#define MAX_OUTPUT_LED      ((unsigned portCHAR) 7)

#define PUSH_SW01		    (PIND&(1<<PIND0))

// Bit Manipulation
#define output_high(p, b)   (p) |= (1 << (b))
#define output_low(p, b)    (p) &= ~(1 << (b))
#define output_toggle(p,b)  (!(p&(1<<b)) ? (output_high(p,b)):(output_low(p,b)))

#define nTick    150      // Perform an action every 150 ticks.


//----------------------------------------:FUNCTION

// InitialisePort
void InitialisePort(void)
{
  unsigned portCHAR ucCurrentOutputValue = 0x00;

  // Set port A direction to outputs.  Start with all output off.
  DDRA = ALL_BITS_OUTPUT;
  PORTA = ucCurrentOutputValue;
}


//----------------------------------------:TASK

// LED1 Task
void Task_LED1(void * pvParameters)
{
  // Perform an action every n ticks.
  const portTickType xFrequency = nTick;
  portTickType xLastWakeTime;

  // Initialise the xLastWakeTime variable with the current time.
  xLastWakeTime = xTaskGetTickCount();

  for (;;) {
    // Wait for the next cycle.
    vTaskDelayUntil(&xLastWakeTime, xFrequency);
    output_toggle(PORTA,0);
  }
}

// LED2 Task
void Task_LED2(void * pvParameters)
{
  // Perform an action every n ticks..
  const portTickType xFrequency = nTick * 2;
  portTickType xLastWakeTime;

  // Initialise the xLastWakeTime variable with the current time.
  xLastWakeTime = xTaskGetTickCount();

  for (;;) {
    // Wait for the next cycle.
    vTaskDelayUntil(&xLastWakeTime, xFrequency);
    output_toggle(PORTA,1);
  } 
}

// LED3 Task
void Task_LED3(void * pvParameters)
{
  // Perform an action every n ticks.
  const portTickType xFrequency = nTick * 3;     
  portTickType xLastWakeTime;

  // Initialise the xLastWakeTime variable with the current time.
  xLastWakeTime = xTaskGetTickCount();

  for (;;) {
    // Wait for the next cycle.
    vTaskDelayUntil(&xLastWakeTime, xFrequency);
    output_toggle(PORTA,2);
  } 
}

// SW1 Task
void Task_SW1(void * pvParameters)
{
  // Perform an action every n ticks.
  const portTickType xFrequency = nTick-140;
  portTickType xLastWakeTime;

  // Initialise the xLastWakeTime variable with the current time.
  xLastWakeTime = xTaskGetTickCount();

  for (;;) {
    // Wait for the next cycle.
    vTaskDelayUntil(&xLastWakeTime, xFrequency);

    if (!PUSH_SW01) {
      output_high(PORTA,3);
    } 
    else {
      output_low(PORTA,3);
    }
  } 
}


//----------------------------------------:MAIN

portSHORT main(void)
{
  InitialisePort();

  // Create the task, storing the handle.
  xTaskCreate(Task_LED1, "Task1", configMINIMAL_STACK_SIZE, NULL, TASK1_PRIORITY, NULL);
  xTaskCreate(Task_LED2, "Task2", configMINIMAL_STACK_SIZE, NULL, TASK2_PRIORITY, NULL);
  xTaskCreate(Task_LED3, "Task3", configMINIMAL_STACK_SIZE, NULL, TASK3_PRIORITY, NULL);
  xTaskCreate(Task_SW1,  "Task4", configMINIMAL_STACK_SIZE, NULL, TASK4_PRIORITY, NULL);
		
  // In this port, to use preemptive scheduler define configUSE_PREEMPTION 
  // as 1 in portmacro.h.  To use the cooperative scheduler define 
  // configUSE_PREEMPTION as 0.
  vTaskStartScheduler();

  return 0;
}
