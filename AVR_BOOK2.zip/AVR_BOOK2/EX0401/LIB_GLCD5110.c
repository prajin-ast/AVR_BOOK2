/*
 ******************************************************************************
 * Workfile    : LIB_GLCD5110.C
 * Purpose     : NOKIA LCD 5110 Library
 * Author      : Prajin Palangsantikul
 * Copyright   : appsofttech co.,ltd.
 * Compiler    : WinAVR Compiler
 * Target      : ATmega AVR MCU
 * Ref         :
 * Date        : 11/07/2007
 ******************************************************************************
*/

/*** Define PIN GLCD 5110 */
#define PORT_SPI    PORTB       // SPI PORT EN
#define DDR_SPI     DDRB        // SPI PORT PIN

#define DD_ENB      DDB0        // ENB (GLCD5110:SCE pin)  	(PB0) 
#define DD_MOSI     DDB5        // MOSI(GLCD5110:SDIN pin)  (PB5)
#define DD_SCK      DDB7        // SCK (GLCD5110:SCLK pin)	(PB7)
#define DD_SS       DDB4        // SS  (GLCD5110:LED pin)   (PB4)
#define DD_DC       DDB1        // GLCD5110:D/C pin         (PB1)
#define DD_RESET    DDB2        // GLCD5110:RESET pin       (PB2)

#define GLCD_X_RES	84
#define GLCD_Y_RES	48

#define GLCD_SIZE	((GLCD_X_RES * GLCD_Y_RES) / 8)

#include "font5x7.h"

void GLCD_Reset(void);
void GLCD_Clear(void);
void GLCD_Init(void);
void GLCD_GotoXY(uint8_t x, uint8_t y);
void GLCD_PutChar(uint8_t ch,uint8_t sp);
void GLCD_PutStr(uint8_t *str,uint8_t sp);

/*
 ******************************************************************************
 * PROTOTYPE FUNCTION
 ******************************************************************************
*/

/*** Reset */
void GLCD_Reset(void)
{
    delay_ms(500);
    sbi(PORT_SPI, DD_RESET);		// GLCD Reset
    delay_ms(10);
    cbi(PORT_SPI, DD_RESET);
    delay_ms(10);
    sbi(PORT_SPI, DD_RESET);
    delay_ms(10);
}

/*** Clear Screen */
void GLCD_Clear(void)
{
    int i;

    sbi(PORT_SPI, DD_DC);			// write data

    for (i=0;i<GLCD_SIZE;i++) {
        SPI_MasterTransmit(0x00);
    }
}

/*** Initialize GLCD */
void GLCD_Init(void)
{	
    cbi(PORT_SPI, DD_ENB);			// GLCD Enable

    GLCD_Reset();

    cbi(PORT_SPI, DD_DC);		// write command	
    SPI_MasterTransmit(0x21);
    SPI_MasterTransmit(0xC8);
    SPI_MasterTransmit(0x06);
    SPI_MasterTransmit(0x13);
    SPI_MasterTransmit(0x20);
    SPI_MasterTransmit(0x0C);

    GLCD_Clear();
}

/*** Goto X,Y */
void GLCD_GotoXY(uint8_t x, uint8_t y)
{
    cbi(PORT_SPI, DD_DC);			// write command
    SPI_MasterTransmit((0x80)|x);	// X-Address = 0
    SPI_MasterTransmit((0x40)|y);	// Y-Address = 0
}

/*** Put character */
void GLCD_PutChar(uint8_t ch, uint8_t sp)
{
    uint16_t p;
	
//	sbi(PORT_SPI, DD_DC);		// write data

    if ((ch<0x20)||(ch>0x7F))
        return;

    p = (ch-32)*5;				// Position ASCII 

    for (ch=0;ch<5;ch++) {	
        SPI_MasterTransmit(pgm_read_byte(&Font5x7[p++]));
    }
	
    if (sp) SPI_MasterTransmit(0x00);	// Space character
}

/*** Put String */
void GLCD_PutStr(uint8_t *str,uint8_t sp)
{
    sbi(PORT_SPI, DD_DC);			// write data

    while (*str) {
        GLCD_PutChar(*str++, sp);
    }
}
