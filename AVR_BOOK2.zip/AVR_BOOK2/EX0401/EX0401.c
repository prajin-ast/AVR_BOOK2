/*-----------------------------------------
File      : EX0401.c
Purpose   : NOKIA LCD 5110
Compiler  : AVR Studio/WinAVR
Target    : ATmega16 
------------------------------------------*/

//----------------------------------------:INCLUDE

#include <avr/io.h>             // AVR device-specific IO definitions
#include <avr/interrupt.h>	    // Interrupt Service routine
#include <compat/deprecated.h>  // Use sbi(), cbi() function
#include <avr/pgmspace.h>       // Program Space String Utilities

#define F_CPU 8000000UL         // XTAL 8 MHz
#include <util/delay.h>         // header file implement simple delay loops


//----------------------------------------:PROTOTYPE FUNCTION

void delay_ms(uint16_t i);
void SPI_MasterInit(void);
void SPI_MasterTransmit(uint8_t cData);

#include "LIB_GLCD5110.C"		// GLCD5110 Library 


//----------------------------------------:FUNCTION

// delay miliseconds
void delay_ms(uint16_t i)
{
  for (;i > 0; i--)
    _delay_ms(1);
}

// SPI Master Init
void SPI_MasterInit(void)
{	
  // Set MOSI, SCK , ENB , DC, RESET output
  DDR_SPI = (1<<DD_MOSI)|(1<<DD_SCK)|(1<<DD_ENB);
  DDR_SPI |= (1<<DD_DC)|(1<<DD_RESET);

  // Enable SPI, Master, set clock rate fck/64 
  SPCR = (1<<SPE)|(1<<MSTR)|(1<<SPR1)|(0<<SPR0);
}

// SPI Master Transmit
void SPI_MasterTransmit(uint8_t cData)
{        
  // Start transmission
  SPDR = cData;                   
  // Wait for transmission complete
  while (!(SPSR & (1<<SPIF)))   
    ;
}


//----------------------------------------:MAIN

int main(void)
{           
  SPI_MasterInit();       // Initialize SPI

  sbi(DDR_SPI, DD_SS);    // Set DD_SS (LED pin) output
  cbi(PORT_SPI, DD_SS);   // Disable BackLight

  GLCD_Init();            // Initialize GLCD

  GLCD_GotoXY(7,1);
  GLCD_PutStr("NOKIA LCD 5110",0);
  GLCD_GotoXY(10,3);
  GLCD_PutStr("Graphic LCD",1);

  while (1) {         // Loop Nothing
  }

  return 0;
}
