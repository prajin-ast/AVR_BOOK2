/*-----------------------------------------
File      : EX1402.c
Purpose   : Interrupt UART0 Module
Compiler  : AVR Studio/WinAVR
Target    : ATmega128 
------------------------------------------*/

//----------------------------------------:INCLUDE

#include <avr/io.h>         // AVR device-specific IO definitions
#include <avr/interrupt.h>	// Interrupt Service routine
#include <compat/deprecated.h>  // Use sbi(), cbi() function

#define F_CPU 16000000UL    // XTAL 16 MHz
#include <util/delay.h>     // header file implement simple delay loops
 
#define RX_BUFSIZE  20      // Buffer RX
unsigned char rx_buf[RX_BUFSIZE];


//----------------------------------------:FUNCTION
 
// delay miliseconds
void delay_ms(uint16_t i)
{
  for (;i > 0; i--)
    _delay_ms(1);
}

// Put String
void put_str(unsigned char *s)
{
  while (*s !=0)
  {
    // wait for empty transmit buffer
    loop_until_bit_is_set(UCSR0A, UDRE0);
    // put data into buffer sends the data
    UDR0 = *s++;
  }
}

// Initialize USART0 Interrupt
void USART_Init(void)
{
  unsigned char baud;

  // Set baud rate
  baud = 103;   // baudrate to 9,600 bps using a 16MHz crystal  
  UBRR0H = (unsigned char) (baud>>8);
  UBRR0L = (unsigned char) baud;
    
  // Enable receiver and tramsmitter
  UCSR0B = (1<<RXEN0)|(1<<TXEN0)|(0<<UCSZ02);

  // Set frame format: 8data, NoneParity, 1stop bit
  UCSR0C = (1<<USBS0)|(1<<UCSZ01)|(1<<UCSZ00);

  // Interrupt USART0 enable
  UCSR0B |= (1<<RXCIE0)|(1<<TXCIE0);
  // Global Interrupt enable
  sei();

}

//----------------------------------------:MAIN

int main(void)
{          
  // Set PF0/PF1 output
  DDRF = (1<<DDF1)|(1<<DDF0);

  // USART0 9,600 bps, 8:N:1 using a 16MHz crystal
  USART_Init();      
     
  put_str("\nUSART0 Module : USART0 Interrupt\n\r");

  while(1) {        // Loop forever                  
    sbi(PORTF,0);   // PF0 High
    cbi(PORTF,1);   // PF1 Low
    delay_ms(500);  // Delay 0.5 sec
    cbi(PORTF,0);   // PF0 Low
    sbi(PORTF,1);   // PF1 High
    delay_ms(500);  // Delay 0.5 sec

  }

  return 0;
}

//----------------------------------------:INTERRUPT FUNCTION

// USART0, RX complete interrupt
ISR (USART0_RX_vect)
{  
  unsigned char c;
  static char i=0;

  c = UDR0;             // Receive Data
  
  if (c=='\r') {      
    put_str("\n\r");    // NewLine & Return
    put_str(rx_buf);    // Put string
    put_str("\n\r");
    for(i=0;i<20;i++) 
      rx_buf[i] = ' ';  // Clear array rx_buf
    i = 0;
    return;
  } 

  rx_buf[i++] = c;

  if (i >= 20) i =0;

  // wait for empty transmit buffer
  loop_until_bit_is_set(UCSR0A, UDRE0);
  UDR0 = c;           // Transmit Data

  return;
}

// USART0, TX complete interrupt
ISR (USART0_TX_vect)
{
  return;
}
