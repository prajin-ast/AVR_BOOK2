/*-----------------------------------------
File      : EX0801.c
Purpose   : Menu LCD Project
Compiler  : AVR Studio/WinAVR
Target    : ATmega16 
------------------------------------------*/

//----------------------------------------:INCLUDE

#include <avr/io.h>             // AVR device-specific IO definitions
#include <compat/deprecated.h>  // Use sbi(), cbi() function
#include <avr/pgmspace.h>       // Program Space String Utilities

#define F_CPU 8000000UL         // XTAL 8 MHz
#include <util/delay.h>         // header file implement simple delay loops

//#define LCD_PORTC			    // Use PORTC control LCD Modules
#include "LIB_LCD.C"            // LCD Library 

#define MAX_M_MENU      4       // Main Menu
#define MAX_S_MENU      4       // Sub Menu
#define DLY_MSG         10      // Delay message show on LCD

#define PUSH_SW01		(PIND&(1<<PIND0))
#define PUSH_SW02		(PIND&(1<<PIND1))
#define PUSH_SW03		(PIND&(1<<PIND2))

const char mm1 []  PROGMEM = "-> Main Menu 1";
const char mm11 [] PROGMEM = "-> Sub Menu 1.1 ";
const char mm12 [] PROGMEM = "-> Sub Menu 1.2 ";
const char mm13 [] PROGMEM = "-> Sub Menu 1.3 ";
const char mm14 [] PROGMEM = "-> Sub Menu 1.4 ";

const char mm2 []  PROGMEM = "-> Main Menu 2";
const char mm21 [] PROGMEM = "-> Sub Menu 2.1 ";
const char mm22 [] PROGMEM = "-> Sub Menu 2.2 ";
const char mm23 [] PROGMEM = "-> Sub Menu 2.3 ";
const char mm24 [] PROGMEM = "-> Sub Menu 2.4 ";

const char mm3 []  PROGMEM = "-> Main Menu 3";
const char mm31 [] PROGMEM = "-> Sub Menu 3.1 ";
const char mm32 [] PROGMEM = "-> Sub Menu 3.2 ";
const char mm33 [] PROGMEM = "-> Sub Menu 3.3 ";
const char mm34 [] PROGMEM = "-> Sub Menu 3.4 ";

const char mm4 []  PROGMEM = "-> Main Menu 4";
const char mm41 [] PROGMEM = "-> Sub Menu 4.1 ";
const char mm42 [] PROGMEM = "-> Sub Menu 4.2 ";
const char mm43 [] PROGMEM = "-> Sub Menu 4.3 ";
const char mm44 [] PROGMEM = "-> Sub Menu 4.4 ";

PGM_P mm[][5] PROGMEM = {
  {mm1, mm11, mm12, mm13, mm14},
  {mm2, mm21, mm22, mm23, mm24},
  {mm3, mm31, mm32, mm33, mm34},
  {mm4, mm41, mm42, mm43, mm44},
};

const char sm11 [] PROGMEM = "You Select 1.1";
const char sm12 [] PROGMEM = "You Select 1.2";
const char sm13 [] PROGMEM = "You Select 1.3";
const char sm14 [] PROGMEM = "You Select 1.4";
const char sm21 [] PROGMEM = "You Select 2.1";
const char sm22 [] PROGMEM = "You Select 2.2";
const char sm23 [] PROGMEM = "You Select 2.3";
const char sm24 [] PROGMEM = "You Select 2.4";
const char sm31 [] PROGMEM = "You Select 3.1";
const char sm32 [] PROGMEM = "You Select 3.2";
const char sm33 [] PROGMEM = "You Select 3.3";
const char sm34 [] PROGMEM = "You Select 3.4";
const char sm41 [] PROGMEM = "You Select 4.1";
const char sm42 [] PROGMEM = "You Select 4.2";
const char sm43 [] PROGMEM = "You Select 4.3";
const char sm44 [] PROGMEM = "You Select 4.4";

PGM_P sm[16] PROGMEM = {
  sm11, sm12, sm13, sm14,
  sm21, sm22, sm23, sm24,
  sm31, sm32, sm33, sm34,
  sm41, sm42, sm43, sm44,
};

const char msg1 [] PROGMEM = "Pls. Key SW1";
const char msg2 [] PROGMEM = "Select Menu..";
const char msg3 [] PROGMEM = "SW1 to Main Menu";
const char msg4 [] PROGMEM = "SW2 to Sub Menu";
const char msg5 [] PROGMEM = "SW3 to Select   ";

PGM_P msg[5] PROGMEM = {
  msg1, msg2, msg3, msg4, msg5
};

// pm:process menu, xm:MainMenu, ym:SubMenu, tmp_xm:Store xm
uint8_t pm=0, xm=0, ym=1,tmp_xm;

//----------------------------------------:FUNCTION

// delay miliseconds
void delay_ms(uint16_t i)
{
  for (;i > 0; i--)
    _delay_ms(1);
}

// menu dsp
void menu_dsp()
{        
  char buf[16];
  PGM_P p;

  // Main Menu
  if(!PUSH_SW01) {
    delay_ms(10);           // Debound key
    while(!PUSH_SW01);      // Wait for Keyup

    // Temp for select main menu
    tmp_xm = xm;

    // Up/Down main menu
    if(xm++ >= (MAX_M_MENU-1)) {    
      xm=0;				
    }
    pm = 1;                 // Set for select sub menu
    ym = 0;                 // Display MainMenu

    LCD_Command(0x01);	    // Clear screen lcd
		
    memcpy_P(&p, &mm[tmp_xm][ym], sizeof(PGM_P));
    strcpy_P(buf,p);
    LCD_GotoXY(1,1); 
    LCD_PutStr(0,buf);

    memcpy_P(&p, &msg[3], sizeof(PGM_P));
    strcpy_P(buf,p);
    LCD_GotoXY(1,2);
    LCD_PutStr(0,buf);
	}

    // Sub Menu
  if(!PUSH_SW02 && pm!=0) {           
    delay_ms(10);           
    while(!PUSH_SW02);

    // Up/Down sub menu
    if(ym++ >= MAX_S_MENU) {
      ym=1;
    }

    pm = 2;                 // Set for Show menu select
		
    memcpy_P(&p, &mm[tmp_xm][ym], sizeof(PGM_P));
    strcpy_P(buf,p);
    LCD_GotoXY(1,1);
    LCD_PutStr(0,buf);

    memcpy_P(&p, &msg[4], sizeof(PGM_P));
    strcpy_P(buf,p);    
    LCD_GotoXY(1,2);
    LCD_PutStr(0,buf);
	}
}

// menu process
void menu_process()
{
  char buf[16];
  PGM_P p;

  if (pm != 2) return;    // Exit if pm=0

  LCD_Command(0x01);		// Clear screen lcd	

	switch(tmp_xm) {
    case 0: ym = ym - 1;    // Select Menu 1.1-1.4
      break;
    case 1: ym = ym + 3;    // Select Menu 2.1-2.4
      break;
    case 2: ym = ym + 7;    // Select Menu 3.1-3.4
      break;
    case 3: ym = ym + 11;   // Select Menu 4.1-4.4
      break;
    default:
      break;
	}
        
  memcpy_P(&p, &sm[ym], sizeof(PGM_P));
  strcpy_P(buf,p);    
  LCD_GotoXY(1,1);
  LCD_PutStr(DLY_MSG,buf);
        
  memcpy_P(&p, &msg[2], sizeof(PGM_P));
  strcpy_P(buf,p);    
  LCD_GotoXY(1,2);
  LCD_PutStr(0,buf);

  xm = 0;     // Clear menu
  ym = 1;
  pm = 0;
}


//----------------------------------------:MAIN

int main(void)
{          
  char buf[16];
  PGM_P p;

  // Set PD0/PD1/PD2 Input
  DDRD = (0<<DDD2)|(0<<DDD1)|(0<<DDD0);    

  Init_LCD();          		// Init LCD Display
    
  memcpy_P(&p, &msg[0], sizeof(PGM_P));
  strcpy_P(buf,p);
  LCD_GotoXY(1,1); 
  LCD_PutStr(0,buf);
    
  memcpy_P(&p, &msg[1], sizeof(PGM_P));
  strcpy_P(buf,p);
  LCD_GotoXY(1,2); 
  LCD_PutStr(0,buf);

  while (1) {                 // Loop forever            
	  menu_dsp();             // Check Menu

    if(!PUSH_SW03) {
      delay_ms(20);       // Debound key   
      while(!PUSH_SW03);  // Wait for Keyup            
      menu_process();     // Select Menu 
    }
  }

  return 0;
}
