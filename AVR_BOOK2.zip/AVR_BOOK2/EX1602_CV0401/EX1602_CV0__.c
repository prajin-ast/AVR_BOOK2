/*-----------------------------------------
File      : EX1602_CV0401.c
Purpose   : PORTA Output
Compiler  : CodeVisionAVR
Target    : ATmega128
------------------------------------------*/

//----------------------------------------:INCLUDE

#include <io.h>         // I/O registers definitions
	#ifndef __SLEEP_DEFINED__
	#define __SLEEP_DEFINED__
	.EQU __se_bit=0x20
	.EQU __sm_mask=0x1C
	.EQU __sm_powerdown=0x10
	.EQU __sm_powersave=0x18
	.EQU __sm_standby=0x14
	.EQU __sm_ext_standby=0x1C
	.EQU __sm_adc_noise_red=0x08
	.SET power_ctrl_reg=mcucr
	#endif
#include <delay.h>      // Header file for Function Delay

//----------------------------------------:MAIN

int main(void)
{
    DDRA=0xFF;          // PORT A Output all
    PORTA=0x00;         // Clear port

    while (1) {         // Loop forever
        PORTA = 0xFF;   // Output High
        delay_ms(1000); // Delay 1s
        PORTA = 0x00;   // Output Low
        delay_ms(1000);
    }

    return 0;
}

