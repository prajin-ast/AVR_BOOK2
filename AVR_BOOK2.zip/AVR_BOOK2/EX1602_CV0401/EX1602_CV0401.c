/*-----------------------------------------
File      : EX1602_CV0401.c
Purpose   : PORTA Output
Compiler  : CodeVisionAVR
Target    : ATmega128 
------------------------------------------*/

//----------------------------------------:INCLUDE

#include <io.h>         // I/O registers definitions
#include <delay.h>      // Header file for Function Delay

//----------------------------------------:MAIN

int main(void)
{  
    DDRA=0xFF;          // PORT A Output all
    PORTA=0x00;         // Clear port
                
    while (1) {         // Loop forever
        PORTA = 0xFF;   // Output High
        delay_ms(1000); // Delay 1s
        PORTA = 0x00;   // Output Low
        delay_ms(1000); 
    }

    return 0;
}

