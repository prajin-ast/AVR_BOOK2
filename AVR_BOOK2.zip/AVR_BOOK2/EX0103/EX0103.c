/*-----------------------------------------
File      : EX0103.c
Purpose   : Break statement
Compiler  : AVR Studio/WinAVR
Target    : ATmega16 
------------------------------------------*/

//----------------------------------------:INCLUDE

#include <avr/io.h>         // AVR device-specific IO definitions

#define F_CPU 8000000UL     // XTAL 8 MHz
#include <util/delay.h>     // header file implement simple delay loops


//----------------------------------------:FUNCTION

// delay miliseconds
void delay_ms(uint16_t i)
{
  for (;i > 0; i--)
    _delay_ms(1);
}

// rotate left
uint8_t rotate_left(uint8_t *x, uint8_t i)
{
  for(;i>0;i--)
    *x = (*x<<1) | (*x>>7);
 
  return (*x);                         
}


//----------------------------------------:MAIN

int main(void)
{
  unsigned char count = 0;
  unsigned char rl = 0x01;
    
  DDRA = 0xff;    // set port output
  PORTA = 0;      // clear port

  while (1) {           // loop forever
    PORTA = rl;         // output porta
    rotate_left(&rl,1); // rotate left
    delay_ms(500);      // delay

    if (count++ >=40)   // increment count
      break;            // break loop while
  }

  PORTA = 0xFF;         // high all port
  while (1)             // loop nothing
    ;
  
  return 0;
}
