/*-----------------------------------------
File      : EX1301.c
Purpose   : Asynchronous Timer/Counter0
Compiler  : AVR Studio/WinAVR
Target    : ATmega128 
------------------------------------------*/

//----------------------------------------:INCLUDE

#include <avr/io.h>         // AVR device-specific IO definitions
#include <avr/interrupt.h>  // AVR interrupt
#include <compat/deprecated.h>  // Use sbi(), cbi() function

#define F_CPU 16000000UL    // XTAL 16 MHz
#include <util/delay.h>     // header file implement simple delay loops

#include "LIB_PORT.C"       // AVR PORT Library

//----------------------------------------:FUNCTION

// delay miliseconds
void delay_ms(uint16_t i)
{
  for (;i > 0; i--)
    _delay_ms(1);
}


//----------------------------------------:MAIN

int main(void)
{
  // Disalbe the Timer/Counter0 interrupts
  TIMSK = (0<<OCIE0) | (0<<TOIE0);
  // Asynchronous Timer/Counter0 enable
  ASSR = (1<<AS0);
  // Set Mode CTC & Clock select 1024 prescaling
  TCCR0 = (1<<WGM01)|(1<<CS02)|(1<<CS01)|(1<<CS00);

  // Clear Timer/Counter0 register
  TCNT0 = 0;
  // Set output compare value to 32
  OCR0 = 32;

  // Wait for reqisters to update
  while(ASSR&(1<<OCR0UB))
    ;

  // Clear Timer/Counter0 Compare Match interrupt flags
  TIFR = (1<<OCF0);
  // Timer/Counter0 Compare Match enable
  TIMSK = (1<<OCIE0);
  // Global interrupt enable
  sei();            

  DDRF = 0xFF;      // Set port output 

  while(1)
  {    
    delay_ms(1000);    
    output_toggle(PORTF,0);  // Use PF0    
  }
}


//----------------------------------------:FUNCTION INTERRUPT

// Timer/Counter0 Compare Match
ISR(TIMER0_COMP_vect)
{   
  output_toggle(PORTF,1);  // Use PF1
}
