/*
 ******************************************************************************
 * Workfile    : LIB_PORT.C
 * Purpose     : AVR PORT Library
 * Author      : Prajin Palangsantikul
 * Copyright   : appsofttech co.,ltd.
 * Compiler    : WinAVR Compiler
 * Target      : ATmega AVR MCU
 * Ref         :
 * Date        : 20/11/2006
 ******************************************************************************
*/


#if defined (__AVR_ATmega16__)
#include <avr/iom16.h>
#endif

/*
 ******************************************************************************
 * DEFINES
 ******************************************************************************
*/

/*** Bit Manipulation */
#define output_high(p, b) 	(p) |= (1 << (b))
#define output_low(p, b)	(p) &= ~(1 << (b))
#define output_toggle(p,b)	(!(p&(1<<b)) ? (output_high(p,b)):(output_low(p,b)))

#define input_bit(p,b)		(p&(1<<b)) 

/*** Byte Manipulation */
#define set_ddr_a(byte)     (DDRA = byte)
#define set_ddr_b(byte)     (DDRB = byte)
#define set_ddr_c(byte)     (DDRC = byte)
#define set_ddr_d(byte)     (DDRD = byte)

#define output_a(byte)      (PORTA = byte)
#define output_b(byte)      (PORTB = byte)
#define output_c(byte)      (PORTC = byte)
#define output_d(byte)      (PORTC = byte)

#define input_a(byte)       (PINA)
#define input_b(byte)       (PINB)
#define input_c(byte)       (PINC)
#define input_d(byte)       (PIND)
