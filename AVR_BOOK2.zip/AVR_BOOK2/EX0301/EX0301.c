/*-----------------------------------------
File      : EX0301.c
Purpose   : 8-Bit Serial-Input/Serial or 
          : Parallel-Output Shift Register
Compiler  : AVR Studio/WinAVR
Target    : ATmega16 
------------------------------------------*/

//----------------------------------------:INCLUDE

#include <avr/io.h>         // AVR device-specific IO definitions
#include <compat/deprecated.h>  // Use sbi(),cbi() function

#define F_CPU 8000000UL     // XTAL 8 MHz
#include <util/delay.h>     // header file implement simple delay loops

#define DDR_SR  DDRA        // direction port shift register
#define PORT_SR PORTA       // output port

#define DS_PIN      PA0      // serial data input
#define SH_CP_PIN   PA1      // shift register clock input
#define ST_CP_PIN   PA2      // storage register clock input

#define SET_INP(x)      cbi(DDR_SR,x)
#define SET_OUTP(x)     sbi(DDR_SR,x)

#define SET_P(x)        sbi(PORT_SR,x)
#define CLS_P(x)        cbi(PORT_SR,x)


//----------------------------------------:NOTE
/*
 74HC595; 74HCT595
 8-bit serial-in, serial or parallel-out shift
 register with output latches; 3-state   
       ----
 Q1  -|    |- Vcc
 Q2  -|    |- Q0
 Q3  -|    |- DS
 Q4  -|    |- /OE
 Q5  -|    |- ST_CP
 Q6  -|    |- SH_CP
 Q7  -|    |- /MR
 GND -|    |- Q7'
       ----
*/


//----------------------------------------:FUNCTION

// delay miliseconds
void delay_ms(uint16_t i)
{
  for (;i > 0; i--)
    _delay_ms(1);
}

// rotate left
uint8_t rotate_left(uint8_t *x, uint8_t i)
{
  for(;i>0;i--)
    *x = (*x>>1) | (*x<<7);

  return (*x);                         
}

// Data transfers
void shift_out_data(uint8_t dat)
{
  unsigned char i;

  for(i=0;i<=8;i++) {	
    if(dat & 0x80)        // serial data in
      SET_P(DS_PIN);  
    else
      CLS_P(DS_PIN);			

    SET_P(SH_CP_PIN);     // clock pulse
    CLS_P(SH_CP_PIN);	
        
    SET_P(ST_CP_PIN);     //  latch pulse
    CLS_P(ST_CP_PIN);

    dat = rotate_left(&dat,1);    // rotate left
	}
}


//----------------------------------------:MAIN

int main(void)
{
  // set output port
  SET_OUTP(DS_PIN);
  SET_OUTP(SH_CP_PIN);
  SET_OUTP(ST_CP_PIN);

  while (1) {               // loop forever
    shift_out_data(0x0F);   // output
    delay_ms(1000);         // delay 1s
    shift_out_data(0xF0);
    delay_ms(1000);
    shift_out_data(0xAA);
    delay_ms(1000);
    shift_out_data(0x55);
    delay_ms(1000);
  }

  return 0;
}
