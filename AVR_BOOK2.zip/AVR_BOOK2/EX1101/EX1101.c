/*-----------------------------------------
File      : EX1101.c
Purpose   : Output PORTA
Compiler  : AVR Studio/WinAVR
Target    : ATmega128 
------------------------------------------*/

//----------------------------------------:INCLUDE

#include <avr/io.h>         // AVR device-specific IO definitions
#include <compat/deprecated.h>  // Use sbi(), cbi() function

#define F_CPU 16000000UL    // XTAL 16 MHz
#include <util/delay.h>     // header file implement simple delay loops

#define DLY   10

//----------------------------------------:FUNCTION

// delay miliseconds
void delay_ms(uint16_t i)
{
  for (;i > 0; i--)
    _delay_ms(1);
}

//----------------------------------------:MAIN

int main(void)
{    
  char portPin;
  int dly = 0, diff = DLY;
  
  DDRF = 0xff;        // set port output
  PORTF = 0;          // clear port

  while (1) {         // loop forever    
    for (portPin = 0; portPin < 3; portPin++ ) {
      sbi(PORTF,portPin);
      delay_ms(dly);
      cbi(PORTF,portPin);
    }
    // change delay
    dly += diff;
    if ( dly > 200 )
      diff = -DLY;
    if ( dly < 0 ) {
      diff = DLY;
      dly = 0;
    }
  }

  return 0;
}
