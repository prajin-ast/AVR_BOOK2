/*
 ******************************************************************************
 * Workfile    : LIB_GGLCD.C
 * Purpose     : AVR Graphics GLCD Library
 * Author      : Prajin Palangsantikul
 * Copyright   : appsofttech co.,ltd.
 * Compiler    : WinAVR Compiler
 * Target      : ATmega AVR MCU
 * Ref         : PIC C GLCD Library
 * Date        : 26/03/2008
 ******************************************************************************
*/

#include <stdlib.h>

void GGLCD_line(char x1, char y1, char x2, char y2, char color);
void GGLCD_rect(char x1, char y1, char x2, char y2, char fill, char color);
void GGLCD_circle(char x, char y, char radius, char fill, char color);
void GGLCD_bar(char x1, char y1, char x2, char y2, char width, char color);
void GGLCD_text57(char x, char y, unsigned char* content);

/*** Draw a line on a graphic LCD using Bresenham's */
void GGLCD_line(char x1, char y1, char x2, char y2, char color)
{
   int          dy, dx;
   signed char  addx=1, addy=1;
   signed int   P, diff;

   char i=0;
   dx = abs((signed char)(x2 - x1));
   dy = abs((signed char)(y2 - y1));

   if(x1 > x2)
      addx = -1;
   if(y1 > y2)
      addy = -1;

   if(dx >= dy)
   {
      dy *= 2;
      P = dy - dx;
      diff = P - dx;

      for(; i<=dx; ++i)
      {
         GLCD_pixel(x1, y1, color);

         if(P < 0)
         {
            P  += dy;
            x1 += addx;
         }
         else
         {
            P  += diff;
            x1 += addx;
            y1 += addy;
         }
      }
   }
   else
   {
      dx *= 2;
      P = dx - dy;
      diff = P - dy;

      for(; i<=dy; ++i)
      {
         GLCD_pixel(x1, y1, color);

         if(P < 0)
         {
            P  += dx;
            y1 += addy;
         }
         else
         {
            P  += diff;
            x1 += addx;
            y1 += addy;
         }
      }
   }
}


/*** Draw a rectangle on a graphic LCD */
void GGLCD_rect(char x1, char y1, char x2, char y2, char fill, char color)
{
   if(fill)
   {
      char  i, xmin, xmax, ymin, ymax;

      if(x1 < x2)                            //  Find x min and max
      {
         xmin = x1;
         xmax = x2;
      }
      else
      {
         xmin = x2;
         xmax = x1;
      }

      if(y1 < y2)                            // Find the y min and max
      {
         ymin = y1;
         ymax = y2;
      }
      else
      {
         ymin = y2;
         ymax = y1;
      }

      for(; xmin <= xmax; ++xmin)
      {
         for(i=ymin; i<=ymax; ++i)
         {
            GLCD_pixel(xmin, i, color);
         }
      }
   }
   else
   {
      GGLCD_line(x1, y1, x2, y1, color);      // Draw the 4 sides
      GGLCD_line(x1, y2, x2, y2, color);
      GGLCD_line(x1, y1, x1, y2, color);
      GGLCD_line(x2, y1, x2, y2, color);
   }
}

/*** Draw a bar (wide line) on a graphic LCD */
void GGLCD_bar(char x1, char y1, char x2, char y2, char width, char color)
{
   char         half_width;
   signed char dy, dx;
   signed char  addx=1, addy=1, j;
   signed char P, diff, c1, c2;

   char i=0;
   dx = abs((signed char)(x2 - x1));
   dy = abs((signed char)(y2 - y1));

   half_width = width/2;
   c1 = -(dx*x1 + dy*y1);
   c2 = -(dx*x2 + dy*y2);

   if(x1 > x2)
   {
      signed char temp;
      temp = c1;
      c1 = c2;
      c2 = temp;
      addx = -1;
   }
   if(y1 > y2)
   {
      signed char temp;
      temp = c1;
      c1 = c2;
      c2 = temp;
      addy = -1;
   }

   if(dx >= dy)
   {
      P = 2*dy - dx;
      diff = P - dx;

      for(i=0; i<=dx; ++i)
      {
         for(j=-half_width; j<half_width+width%2; ++j)
         {
            char temp;

            temp = dx*x1+dy*(y1+j);    // Use more RAM to increase speed
            if(temp+c1 >= 0 && temp+c2 <=0)
               GLCD_pixel(x1, y1+j, color);
         }
         if(P < 0)
         {
            P  += 2*dy;
            x1 += addx;
         }
         else
         {
            P  += diff;
            x1 += addx;
            y1 += addy;
         }
      }
   }
   else
   {
      P = 2*dx - dy;
      diff = P - dy;

      for(i=0; i<=dy; ++i)
      {
         if(P < 0)
         {
            P  += 2*dx;
            y1 += addy;
         }
         else
         {
            P  += diff;
            x1 += addx;
            y1 += addy;
         }
         for(j=-half_width; j<half_width+width%2; ++j)
         {
            char temp;

            temp = dx*x1+dy*(y1+j);    // Use more RAM to increase speed
            if(temp+c1 >= 0 && temp+c2 <=0)
               GLCD_pixel(x1+j, y1, color);
         }
      }
   }
}

/*** Draw a circle on a graphic LCD */
void GGLCD_circle(char x, char y, char radius, char fill, char color)
{
   signed char  a, b, P;

   a = 0;
   b = radius;
   P = 1 - radius;

   do
   {
      if(fill)
      {
         GGLCD_line(x-a, y+b, x+a, y+b, color);
         GGLCD_line(x-a, y-b, x+a, y-b, color);
         GGLCD_line(x-b, y+a, x+b, y+a, color);
         GGLCD_line(x-b, y-a, x+b, y-a, color);
      }
      else
      {
         GLCD_pixel(a+x, b+y, color);
         GLCD_pixel(b+x, a+y, color);
         GLCD_pixel(x-a, b+y, color);
         GLCD_pixel(x-b, a+y, color);
         GLCD_pixel(b+x, y-a, color);
         GLCD_pixel(a+x, y-b, color);
         GLCD_pixel(x-a, y-b, color);
         GLCD_pixel(x-b, y-a, color);
      }

      if(P < 0)
         P += 3 + 2 * a++;
      else
         P += 5 + 2 * (a++ - b--);
    } while(a <= b);
}

/*** Write text on a graphic LCD */
void GGLCD_text57(char x, char y, unsigned char* content)
{
  char bitmap[8] = { 0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x40, 0x80 };
  unsigned char x1, y1;
  unsigned char ch, ascii, k;

  for(k=0; k<strlen(content); k++)
  {
    ascii = content[k]-32;                // Start SP character
    for(y1=0; y1<5; y1++)                 // Loop through character byte data
    {
      ch = pgm_read_dword_near(&font[ascii][y1]); // Read font from Program Memory
      for(x1=0; x1<7; x1++)               // Loop through the vertical pixels
        if((ch & bitmap[x1]) != 0)        // Check if the pixel should be set
          GLCD_pixel((x+k), (y+x1), 1);   // Draws the pixel
        x++;                              // Set x at next position
    }
  }
}
