/*-----------------------------------------
File      : EX1801.c
Purpose   : GLCD 128x64
Compiler  : AVR Studio/WinAVR
Target    : ATmega128 
------------------------------------------*/

//----------------------------------------:INCLUDE

#include <avr/io.h>         // AVR device-specific IO definitions
#include <compat/deprecated.h>  // Use sbi(), cbi() function
#include <avr/pgmspace.h>   // Program spaceString Utilities

#define F_CPU 16000000UL    // XTAL 16 MHz
#include <util/delay.h>     // header file implement simple delay loops

#include "Font5x7.dat"      // Eng Font 5x7

#include "LIB_GLCD.C"       // AVR GLCD Library
#include "LIB_GGLCD.C"      // AVR Graphics GLCD Library


int main(void)
{
  GLCD_init(ON);          // Init
  GLCD_fillScreen(0);     // Clear Screen

  GGLCD_text57(18,5, "Test GLCD 128x64");  // Display 
  GGLCD_text57(13,20, "C with AVR BOOK 2");
  GGLCD_text57( 7,35, "www.appsofttech.com");
  GGLCD_text57(12,50, "-- APPSOFTTECH --");

  while(1)
    ;

	return 0;
}
