/*-----------------------------------------
File      : EX1504.c
Purpose   : LED & 7Segments RTOS
Compiler  : AVR Studio/WinAVR
Target    : ATmega128 
------------------------------------------*/

//----------------------------------------:INCLUDE

// Scheduler include files.
#include "FreeRTOS.h"		
#include "task.h"

// Priority definitions for most of the tasks in the demo application.
// Some tasks just use the idle priority.
#define TASK1_PRIORITY		( tskIDLE_PRIORITY + 1 )
#define TASK2_PRIORITY		( tskIDLE_PRIORITY + 2 )
#define TASK3_PRIORITY		( tskIDLE_PRIORITY + 3 )

// Constant data for I/O
#define ALL_BITS_OUTPUT		( ( unsigned portCHAR ) 0xff )
#define ALL_OUTPUTS_OFF		( ( unsigned portCHAR ) 0x00 )
#define MAX_OUTPUT_LED    ( ( unsigned portCHAR ) 7 )

// Bit Manipulation
#define output_high(p, b)   (p) |= (1 << (b))
#define output_low(p, b)    (p) &= ~(1 << (b))
#define output_toggle(p,b)  (!(p&(1<<b)) ? (output_high(p,b)):(output_low(p,b)))

// 7 Segments LED
#define LED_DATA_DDR    DDRA        // LED Display (DATA_PORT)    
#define LED_DATA_POUT   PORTA
#define LED_CTL_DDR     DDRB        // DSPx enable (DIGIT PORT)
#define LED_CTL_DSP     PORTB	        


const unsigned char num_led[19] = {0x3F, 0x06, 0x5B, 0x4F, 0x66,  //0,1,2,3,4
                                   0x6D, 0x7D, 0x07, 0x7F, 0x6F,  //5,6,7,8,9
                                   0x77, 0x7C, 0x39, 0x5E, 0x79,  //A,b,C,d,E
                                   0x71, 0x80, 0x5C, 0x76         //F,.,o,H
                                  };
const unsigned char ctl_led[4] = {0x07, 0x0B, 0x0D, 0x0E};
unsigned char num[4];

//----------------------------------------:FUNCTION

// InitialisePort
void InitialisePort( void )
{
  unsigned portCHAR ucCurrentOutputValue = 0x00;

  // Set PORTA/PORTB
  LED_DATA_DDR = ALL_BITS_OUTPUT;	    // PORTA Control LED 7-Segments
  LED_CTL_DDR = 0x0F;                 // PORTB PA0-PA3 Control Digit

  // Set PORT C All output
  DDRC = ALL_BITS_OUTPUT;
  PORTC = ucCurrentOutputValue;
}


//----------------------------------------:TASK

// Task Display LED 7 Segments
void Task_DspSegments(void * pvParameters)
{
  char iCount=0;
  
  for( ;; ) {        
    LED_DATA_POUT = ~(num_led[num[iCount]]);			
    LED_CTL_DSP = ctl_led[iCount];        // DSP enable active
    vTaskDelay(2);
    if (iCount++ >3) iCount = 0;
  }
}

// Task Counter Number
void Task_CountNumber(void * pvParameters)
{
  // Perform an action every 1000 ticks.
  const portTickType xFrequency = 1000;
  portTickType xLastWakeTime;

  unsigned int count = 0;
    
  // Initialise the xLastWakeTime variable with the current time.
  xLastWakeTime = xTaskGetTickCount ();

  for( ;; ) {
    // Wait for the next cycle.
    vTaskDelayUntil(&xLastWakeTime, xFrequency);

    num[0] = ((count%1000)%100)%10;     // First Digit
    num[1] = ((count%1000)%100)/10;     // Second Digit
    num[2] = (count%1000)/100;          // Third Digit
    num[3] = (count/1000);              // Fourth Digit

    if (count++ > 9999) count = 0;    
  } 
}

// Task Shift LED
void Task_ShiftLED(void * pvParameters)
{
  // Perform an action every 100 ticks.
  const portTickType xFrequency = 100;
  portTickType xLastWakeTime;

  unsigned char i=0x01;

  // Initialise the xLastWakeTime variable with the current time.
  xLastWakeTime = xTaskGetTickCount ();

  for( ;; ) {
	  // Wait for the next cycle.
    vTaskDelayUntil(&xLastWakeTime, xFrequency);
    PORTC = i;
    i = i<<1;
    if (i==0x00) i= 0x01;
  } 
}


//----------------------------------------:MAIN

portSHORT main(void)
{
  InitialisePort();

  // Create the task, storing the handle.
  xTaskCreate(Task_DspSegments,"Task1", configMINIMAL_STACK_SIZE, NULL, TASK1_PRIORITY, NULL);
  xTaskCreate(Task_CountNumber,"Task2", configMINIMAL_STACK_SIZE, NULL, TASK2_PRIORITY, NULL);  
  xTaskCreate(Task_ShiftLED,   "Task3", configMINIMAL_STACK_SIZE, NULL, TASK3_PRIORITY, NULL);
  	    
  // In this port, to use preemptive scheduler define configUSE_PREEMPTION 
  // as 1 in portmacro.h.  To use the cooperative scheduler define 
  // configUSE_PREEMPTION as 0.
  vTaskStartScheduler();

  return 0;
}
