/*-----------------------------------------
File      : EX1201.c
Purpose   : External Interrupt0
Compiler  : AVR Studio/WinAVR
Target    : ATmega128 
------------------------------------------*/

//----------------------------------------:INCLUDE

#include <avr/io.h>         // AVR device-specific IO definitions
#include <avr/interrupt.h>  // AVR interrupt
#include <compat/deprecated.h>  // Use sbi(), cbi() function

#define F_CPU 16000000UL    // XTAL 16 MHz
#include <util/delay.h>     // header file implement simple delay loops


//----------------------------------------:FUNCTION

// delay miliseconds
void delay_ms(uint16_t i)
{
  for (;i > 0; i--)
    _delay_ms(1);
}


//----------------------------------------:MAIN
int main(void)
{
  DDRF = 0xFF;      // Set port output 
  PORTF = 0x00;     // Clear port

  // Low level interrupt request
  EICRA = (0<<ISC01)|(0<<ISC00);
  // External interrupt request enable
  EIMSK = (1<<INT0);
  // Global interrupt enable
  sei();            

  while(1)
  {
    sbi(PORTF,1);
    cbi(PORTF,2);
    delay_ms(500);
    cbi(PORTF,1);
    sbi(PORTF,2);
    delay_ms(500);
  }
}


//----------------------------------------:FUNCTION INTERRUPT

// External Interrupt0 (PD0 pin)
ISR(INT0_vect)
{
  sbi(PORTF,0);
  delay_ms(500);
  cbi(PORTF,0);
}
