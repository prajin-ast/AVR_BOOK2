/*-----------------------------------------
File      : EX1103.c
Purpose   : Input/Output port
Compiler  : AVR Studio/WinAVR
Target    : ATmega128 
------------------------------------------*/

//----------------------------------------:INCLUDE

#include <avr/io.h>         // AVR device-specific IO definitions
#include <compat/deprecated.h>  // Use sbi(), cbi() function

#define F_CPU 16000000UL    // XTAL 16 MHz
#include <util/delay.h>     // header file implement simple delay loops

#define LCD_PORTC           // LCD PORTC
#include "LIB_LCD.C"


//----------------------------------------:NOTE
// port P1 connect to key switch matrix pull-up
// Px.0 -> R1 , Px.1 -> R2
// Px.2 -> R3 , Px.3 -> R4
// Px.4 -> C1 , Px.5 -> C2
// Px.6 -> C3 , Px.7 not use

#define KEY_DATA_POUT		PORTA
#define KEY_DATA_PIN		PINA
#define KEY_DATA_DDR		DDRA

#define PORT_PULSE      PORTF
#define PIN_PULSE       PINF0
#define DDR_PULSE       DDRF


//----------------------------------------:GLOBAL

const unsigned char kbd_pad[4][3] = {{'7','8','9'},
                                     {'4','5','6'},
                                     {'1','2','3'},
                                     {'*','0','#'}
                                     };

char key_num[4]={0,0,0,0};  
char key_count=1;

//----------------------------------------:FUNCTION

// delay miliseconds
void delay_ms(uint16_t i)
{
  for (;i > 0; i--)
    _delay_ms(1);
}

// get key switch martix
unsigned char get_kbd()
{
    // x[110]1111, x[101]1111, x[011]1111
    unsigned char read_col[3] = { 0x6F, 0x5F, 0x3F }; 
    int col,row;   
    static char last_key;

    for (col=0;col<3;col++) {

        KEY_DATA_POUT = read_col[col];     	// read column 
        delay_ms(10);				 		// debounce

        row = KEY_DATA_PIN & 0x0F;        	// read row

        switch (row) {               
            case 0x0E: row = 3;
                break;
            case 0x0D: row = 2;
                break;
            case 0x0B: row = 1;
                break;
            case 0x07: row = 0;
                break;
            default:                    
                row = 4;
		}        

        if (row!=4) {
            if (kbd_pad[row][col] == last_key) 
              return('\0');                   

            last_key = kbd_pad[row][col];
            return(kbd_pad[row][col]);
        }
    }

    last_key = '\0';
    return(last_key);
}

// Clear Pulse..
void clear_pulse(void)
{
  key_num[0]=key_num[1]=0;
  key_num[2]=key_num[3]=0;    
  key_count=0;

  LCD_Command(0x01);    // LCD Clear
  LCD_GotoXY(1,1);
  LCD_PutStr(0, "PULSE...Set");
}

//----------------------------------------:MAIN

int main(void)
{      
  unsigned int pulse=0;
  char key_ch;

  Init_LCD();          		    // Init LCD Display

  KEY_DATA_DDR = 0xF0;        // Set Port Output/Input
  DDR_PULSE = (1<<PIN_PULSE); // Set Port Output   
  cbi(PORT_PULSE,PIN_PULSE);  // Clear Port  

  while (1) {   
       
    clear_pulse();

    while(1) {
      key_ch = get_kbd();

      if (key_ch !='\0') {

        if (key_ch == '#') break;
        if (key_ch == '*') {
          clear_pulse();
        } else {

          switch(key_count++) {
            case 0: key_num[0] = key_ch -'0';   // change to digit
            break;
            case 1: key_num[1] = key_num[0];
                    key_num[0] = key_ch -'0';
            break;
            case 2: key_num[2] = key_num[1];
                    key_num[0] = key_ch -'0';
            break;
            case 3: key_num[3] = key_num[2];
                    key_num[2] = key_num[1];
                    key_num[0] = key_ch -'0';
            break;
          }

          if(key_count > 4) break;   // Max digit

          LCD_GotoXY(key_count,2);
          LCD_PutChar(key_ch);
          
        }
      }
    }
    
    LCD_GotoXY(1,1);
    LCD_PutStr(0, "PULSE...Out.");
    key_count += 2;
    LCD_GotoXY(key_count,2);
    LCD_PutStr(0, "ms");

    pulse = (unsigned int) ((key_num[3]*1000) + (key_num[2]*100));
    pulse = pulse + (unsigned int) ((key_num[1]*10) + key_num[0]);
        
    while(1) {
      sbi(PORT_PULSE,PIN_PULSE);
      delay_ms(pulse);
      cbi(PORT_PULSE,PIN_PULSE);
      delay_ms(pulse);
    }
    
  }

  return 0;
}
