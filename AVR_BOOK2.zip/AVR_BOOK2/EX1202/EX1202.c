/*-----------------------------------------
File      : EX1202.c
Purpose   : External Interrupt0/4
Compiler  : AVR Studio/WinAVR
Target    : ATmega128 
------------------------------------------*/

//----------------------------------------:INCLUDE

#include <avr/io.h>         // AVR device-specific IO definitions
#include <avr/interrupt.h>  // AVR interrupt
#include <compat/deprecated.h>  // Use sbi(), cbi() function

#define F_CPU 16000000UL    // XTAL 16 MHz
#include <util/delay.h>     // header file implement simple delay loops


//----------------------------------------:FUNCTION

// delay miliseconds
void delay_ms(uint16_t i)
{
  for (;i > 0; i--)
    _delay_ms(1);
}


//----------------------------------------:MAIN
int main(void)
{
  DDRF = 0xFF;      // Set port output 
  PORTF = 0x00;     // Clear port

  // INT0 Low level interrupt request 
  EICRA = (0<<ISC01)|(0<<ISC00);
  // INT4 Low level interrupt request 
  EICRB = (0<<ISC41)|(0<<ISC40);
  // External interrupt request enable
  EIMSK = (1<<INT4)|(1<<INT0);
  // Global interrupt enable
  sei();            

  while(1)
  {
    sbi(PORTF,2);
    cbi(PORTF,3);
    delay_ms(500);
    cbi(PORTF,2);
    sbi(PORTF,3);
    delay_ms(500);
  }
}


//----------------------------------------:FUNCTION INTERRUPT

// External Interrupt0 (PD0 pin)
ISR(INT0_vect)
{
  sbi(PORTF,0);
  delay_ms(500);
  cbi(PORTF,0);
}


// External Interrupt4 (PE4 pin)
ISR(INT4_vect)
{
  sbi(PORTF,1);
  delay_ms(250);
  cbi(PORTF,1);
}
