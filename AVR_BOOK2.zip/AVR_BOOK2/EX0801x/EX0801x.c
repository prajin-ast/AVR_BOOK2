/*-----------------------------------------
File      : EX0801x.c
Purpose   : Menu LCD Project
Compiler  : AVR Studio/WinAVR
Target    : ATmega16 
------------------------------------------*/

//----------------------------------------:INCLUDE

#include <avr/io.h>             // AVR device-specific IO definitions
#include <compat/deprecated.h>  // Use sbi(), cbi() function
#include <avr/pgmspace.h>       // Program Space String Utilities

#define VX_MEGA16

#ifndef VX_MEGA16
    #define F_CPU 8000000UL         // XTAL 8 MHz
    #define PUSH_SW01		(PIND&(1<<PIND0))
    #define PUSH_SW02		(PIND&(1<<PIND1))
    #define PUSH_SW03		(PIND&(1<<PIND2))
    #define SET_OUTP()      (DDRD = (0<<DDD2)|(0<<DDD1)|(0<<DDD0))    
#else
    #define F_CPU 16000000UL         // XTAL 16 MHz
    #define LCD_PORTC			    // Use PORTC control LCD Modules
    #define PUSH_SW01		(PINB&(1<<PINB5))
    #define PUSH_SW02		(PINB&(1<<PINB6))
    #define PUSH_SW03		(PINB&(1<<PINB7))
    #define SET_OUTP()      (DDRB = (0<<DDB7)|(0<<DDB6)|(0<<DDB5))    
#endif

#include <util/delay.h>         // header file implement simple delay loops

#include "LIB_LCD.C"            // LCD Library 

#define MAX_M_MENU      4       // Main Menu
#define MAX_S_MENU      4       // Sub Menu
#define DLY_MSG         10      // Delay message show on LCD

unsigned char *mm[][16] = {
        {"-> Main Menu 1",
        "-> Sub Menu 1.1 ","-> Sub Menu 1.2 ", 
        "-> Sub Menu 1.3 ","-> Sub Menu 1.4 "},
        {"-> Main Menu 2",
        "-> Sub Menu 2.1 ","-> Sub Menu 2.2 ",
        "-> Sub Menu 2.3 ","-> Sub Menu 2.4 "},
        {"-> Main Menu 3",
        "-> Sub Menu 3.1 ","-> Sub Menu 3.2 ",
        "-> Sub Menu 3.3 ","-> Sub Menu 3.4 "},
        {"-> Main Menu 4",
        "-> Sub Menu 4.1 ","-> Sub Menu 4.2 ",
        "-> Sub Menu 4.3 ","-> Sub Menu 4.4 "},
};

unsigned char *sm[] = {
        "You Select 1.1","You Select 1.2",
        "You Select 1.3","You Select 1.4",
        "You Select 2.1","You Select 2.2",
        "You Select 2.3","You Select 2.4",
        "You Select 3.1","You Select 3.2",
        "You Select 3.3","You Select 3.4",
        "You Select 4.1","You Select 4.2",
        "You Select 4.3","You Select 4.4",
};

unsigned char *msg[]  = {
        "Pls. Key SW1",
        "Select Menu..",
        "SW1 to Main Menu",
        "SW2 to Sub Menu",
        "SW3 to Select   ",
};


// pm:process menu, xm:MainMenu, ym:SubMenu, tmp_xm:Store xm
uint8_t pm=0, xm=0,ym=1,tmp_xm;


//----------------------------------------:FUNCTION

// delay miliseconds
void delay_ms(uint16_t i)
{
    for (;i > 0; i--)
        _delay_ms(1);
}

// menu dsp
void menu_dsp()
{   
    unsigned char buf[17];     

    // Main Menu
	if(!PUSH_SW01) {
		delay_ms(10);           // Debound key
		while(!PUSH_SW01);      // Wait for Keyup

        // Temp for select main menu
		tmp_xm = xm;

        // Up/Down main menu
		if(xm++ >= (MAX_M_MENU-1)) {    
            xm=0;				
        }
        pm = 1;                 // Set for select sub menu
		ym = 0;                 // Display MainMenu

		LCD_Command(0x01);	    // Clear screen lcd
		
        LCD_GotoXY(1,1); 
        LCD_PutStr(0,mm[tmp_xm][ym]);

        LCD_GotoXY(1,2);
        LCD_PutStr(0,msg[3]);
	}

    // Sub Menu
	if(!PUSH_SW02 && pm!=0) {           
		delay_ms(10);           
		while(!PUSH_SW02);

        // Up/Down sub menu
		if(ym++ >= MAX_S_MENU) {
            ym=1;
        }

        pm = 2;                 // Set for Show menu select
		
        LCD_GotoXY(1,1);
        LCD_PutStr(0,mm[tmp_xm][ym]);

        LCD_GotoXY(1,2);
        LCD_PutStr(0,msg[4]);
	}
}

// menu process
void menu_process()
{
	if (pm != 2) return;    // Exit if pm=0

    LCD_Command(0x01);		// Clear screen lcd	

	switch(tmp_xm) {
	    case 0: ym = ym - 1;    // Select Menu 1.1-1.4
             break;
	    case 1: ym = ym + 3;    // Select Menu 2.1-2.4
		     break;
	    case 2: ym = ym + 7;    // Select Menu 3.1-3.4
		     break;
	    case 3: ym = ym + 11;   // Select Menu 4.1-4.4
		     break;
	    default:
		     break;
	}
        
    LCD_GotoXY(1,1);
    LCD_PutStr(DLY_MSG,sm[ym]);
    
    LCD_GotoXY(1,2);
    LCD_PutStr(0,msg[2]);

    xm = 0;     // Clear menu
    ym = 1;
    pm = 0;
}

//----------------------------------------:MAIN

int main(void)
{   
    unsigned char buf[17];
   
    SET_OUTP();                 // Set output port
    Init_LCD();          		// Init LCD Display
    
    LCD_GotoXY(1,1); 
    LCD_PutStr(0,msg[0]);
    
    LCD_GotoXY(1,2); 
    LCD_PutStr(0,msg[1]);

    while (1) {                 // Loop forever            
		menu_dsp();             // Check Menu

		if(!PUSH_SW03) {
			delay_ms(20);       // Debound key   
			while(!PUSH_SW03);  // Wait for Keyup            
			menu_process();     // Select Menu 
		}
    }

    return 0;
}

