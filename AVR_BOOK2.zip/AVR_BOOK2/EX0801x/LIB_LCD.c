/******************************************************************************
Author: 		prajin palangsantikul
Company: 		appsofttech co.,ltd.
Filename:		LIB_LCD.c
Purpose:		LCD Character 16x2 Module 4bit Mode
Ref..:			TG_4bitLCD.c [Thorsten Godau, thorsten.godau@gmx.de]
Date: 			15/10/2005
******************************************************************************/

/******************************************************************* Defines */

/*
* LCD PIN
* PORT Control : Low Nibble	
* PORT Data : High Nibble	
*/

#ifdef LCD_PORTC
#define LCD_DATA    PORTC       // Dataport of LCD-Display (D4..D7)
#define LCD_OUT		DDRC		// direction port
#define LCD_RS      PC0         // Register Select of LCD-Display
#define LCD_E       PC2         // Enable of LCD-Display
//#define LCD_RW		PC3			// Read/Write LCD-Display
#else
#define LCD_DATA    PORTB       // Dataport of LCD-Display (D4..D7)
#define LCD_OUT		DDRB		// direction port
#define LCD_RS      PB0         // Register Select of LCD-Display
#define LCD_E       PB2         // Enable of LCD-Display
//#define LCD_RW		PB3			// Read/Write LCD-Display
#endif

#define BLINK       0x01   	 	// Alias for blinking cursor
#define NOBLINK     0x00   	 	// Alias for non blinking cursor
#define SHOW        0x02   	 	// Alias for cursor on
#define HIDE        0x00   	 	// Alias for cursor off
#define ON          0x04   	 	// Alias for display on
#define OFF         0x00   	 	// Alias for display off
#define CLS			0x01		// Clear LCD

#define SET_LCD_RS  	sbi(LCD_DATA,LCD_RS)	// Select data register
#define CLS_LCD_RS  	cbi(LCD_DATA,LCD_RS)	// Select instruction register	
#define SET_LCD_E   	sbi(LCD_DATA,LCD_E)		// Enable of LCD-Display
#define CLS_LCD_E   	cbi(LCD_DATA,LCD_E)		// Disable of LCD-Display
//#define READ_LCD_RW		sbi(LCD_DATA,LCD_RW)	// Read Mode
//#define WRITE_LCD_RW   	cbi(LCD_DATA,LCD_RW)	// Write Mode

/*
* Table to select DD-RAM address (including instruction and address)
* 0x00..0x0F -> Line 1, 0x40..0x4F -> Line 2
*/
static unsigned char LOCATION[2][16] = { {0x80,0x81,0x82,0x83,0x84,0x85,0x86,0x87,
                                          0x88,0x89,0x8A,0x8B,0x8C,0x8D,0x8E,0x8F},
                                         {0xC0,0xC1,0xC2,0xC3,0xC4,0xC5,0xC6,0xC7,
                                          0xC8,0xC9,0xCA,0xCB,0xCC,0xCD,0xCE,0xCF} };

/** Timer dependend LCD_Delay-routine */
void LCD_Delay(unsigned int ms);
/**  Writes a character to display */
void LCD_PutChar(unsigned char value);
/**  Writes a string to display */
void LCD_PutStr(unsigned int dly, unsigned char *text);
/**  Command LCD */
void LCD_Command(unsigned char cmd);
/**  Prints a text to x/y position */
void LCD_PrintXY(unsigned char x,unsigned char y, unsigned int dly, unsigned char *text);
/** Controls the display */
void LCD_Control(unsigned char dsp,unsigned char blink,unsigned char cursor);
/** Sets LCD write position */
void LCD_GotoXY(unsigned char x,unsigned char y);

/***************************************************************** LCD Delay */
/*
* Function : LCD_Delay
* Parameters : i - unsigned int
* Returned : nothing
*/
void LCD_Delay(unsigned int i)
{
    for (;i > 0; i--)
        _delay_ms(1);
}

/*************************************************************** LCD_Control */
/*
* Function    : LCD_Control(dsp,blink,cursor)
* Input : unsigned char dsp    = ON     -> Display on
*                                OFF    -> Display off
*         unsigned char blink  = BLINK  -> Cursor blinks
*                                NOBLINK-> Cursor not blinks
*         unsigned char cursor = SHOW   -> Cursor visible
*                                HIDE   -> Cursor invisible
*
*/
void LCD_Control(unsigned char dsp,unsigned char blink,unsigned char cursor)
{
    unsigned char control;                   // variable to generate instruction byte

    control = (0x08 + blink + cursor + dsp); // Cursor control
    LCD_Command(control);
    return;
}

/**************************************************************** LCD_GotoXY */
/*
* Function    : LCD_GotoXY(x,y)
* Description : Sets the write position of the LCD display
*
*                 (1,1)         (16,1)
*                   |              |
*                   ################   -> line 1
*                   ################   -> line 2
*                   |              |
*                 (1,2)         (16,2)
* Input       : unsigned char x    -> x position (horizontal)
*               unsigned char y    -> y position (vertical)
*/
void LCD_GotoXY(unsigned char x,unsigned char y)
{
    LCD_Delay(20);          // Wait 20ms
    CLS_LCD_E;				// Disable 
    CLS_LCD_RS;             // Switch to inruction register
//	WRITE_LCD;

    /** Set LCD_DATA to high nibble of position table value */
    LCD_DATA = (LCD_DATA&0x0F)|((LOCATION[y-1][x-1])&0xF0);
    SET_LCD_E;  CLS_LCD_E;   // Write data to display
	LCD_Delay(1);  	       	 // Wait 1ms
    /** Set LCD_DATA to lower nibble of position table value */
    LCD_DATA = (LCD_DATA&0x0F)|(((LOCATION[y-1][x-1])<<4)&0xF0);
    SET_LCD_E;  CLS_LCD_E;   // Write data to display

    LCD_Delay(1);           // Wait 1ms
    return;
}

/*************************************************************** LCD_PrintXY */
/*
* Function    : LCD_PrintXY(x,y,*text)
* Description : Prints text to position x/y of the display
* Input       : unsigned char x     -> x position of the display
*               unsigned char y     -> y position of the display
*               unsigned char *text -> pointer to text
*					      unsigned int dly	   -> LCD_Delay time
*/
void LCD_PrintXY(unsigned char x,unsigned char y, unsigned int dly, unsigned char *text)
{
    LCD_GotoXY(x,y);            // Set cursor position
    while ( *text ) {           // while not end of text
        LCD_PutChar(*text++);   // Write character and increment position
        LCD_Delay(dly);			// time LCD_Delay print text
    }
    return;
}

/*************************************************************** LCD_PutChar */
/*
* Function    : LCD_PutChar(value)
* Description : Writes the character value to the display
*/
void LCD_PutChar(unsigned char value)
{
	CLS_LCD_E;				// Disable
    SET_LCD_RS;     		// Switch to data register

    /** Set LCD_DATA to high nibble of value */
    LCD_DATA = (LCD_DATA&0x0F)|(value&0xF0);
    SET_LCD_E;  CLS_LCD_E;	// Write data to display
	LCD_Delay(1);  	        // Wait 1ms
    /** Set LCD_DATA to lower nibble of value */
    LCD_DATA = (LCD_DATA&0x0F)|((value<<4)&0xF0);
    SET_LCD_E;  CLS_LCD_E;  // Write data to display

    LCD_Delay(1);			// Wait 1ms
    return;
}

/**************************************************************** LCD_PutStr */
/*
* Function    : LCD_PutStr(value)
* Description : Writes the string value to the display
*/
void LCD_PutStr(unsigned int dly, unsigned char *text)
{
    while ( *text ) {           // while not end of text
        LCD_PutChar(*text++);   // Write character and increment position
        LCD_Delay(dly);			// time LCD_Delay print text
    }
    return;
}

/*************************************************************** LCD_Command */
void LCD_Command(unsigned char cmd)
{
    LCD_Delay(20);     	    // Wait 20ms
	CLS_LCD_E;				// Disable
    CLS_LCD_RS;             // Switch to inruction register

    /** Set LCD_DATA to high nibble of Display On/Off Control */
    LCD_DATA = (LCD_DATA&0x0F)|(cmd&0xF0);
    SET_LCD_E;  CLS_LCD_E;  // Write data to display
	LCD_Delay(1);  	        // Wait 1ms
    /** Set LCD_DATA to lower nibble of Display On/Off Control */
    LCD_DATA = (LCD_DATA&0x0F)|((cmd<<4)&0xF0);
    SET_LCD_E;  CLS_LCD_E;  // Write data to display

    LCD_Delay(1);  	        // Wait 1ms
    return;
}

/******************************************************************* Init_LCD */
// Initialize LCD Module
void Init_LCD(void)
{
    LCD_OUT = 0xFF;             // Set output port

    /** Set LCD Module 4 bit Mode */
    LCD_Command(0x33);	        // set 4 bit mode
    LCD_Command(0x32);	        // set 4 bit mode
    LCD_Command(0x28);	        // 2 line 5x7 dot
    LCD_Command(0x01);	        // clear screen lcd

    // Display on, cursor hidden and no blinking
    LCD_Control(ON,NOBLINK,HIDE);   
}

