/*
 ******************************************************************************
 * Workfile    : LIB_iUART.C
 * Purpose     : AVR Interrupt UART Library
 * Author      : Prajin Palangsantikul
 * Copyright   : appsofttech co.,ltd.
 * Compiler    : WinAVR Compiler
 * Target      : ATmega AVR MCU
 * Ref         :
 * Date        : 20/06/2007
 ******************************************************************************
*/

/*
 ******************************************************************************
 * INCLUDES
 ******************************************************************************
*/

#include <stdio.h>          // Standard Input/Output
#include <avr/interrupt.h>	// Interrupt Service routine

uint8_t hookLED, iLED, sLED[8];

int8_t c, conn=0;

/*
 ******************************************************************************
 * FUNCTIONS
 ******************************************************************************
*/

/*** put string */
void put_string(unsigned char *s)
{
    while (*s!=0) {
        loop_until_bit_is_set(UCSRA, UDRE);
        UDR = *s++;         // Transmit Data
    }
}

/*** Initialize UART */
static void USART_Init(unsigned int baud)
{
	// Set baud rate
	UBRRH = (unsigned char) (baud>>8);
	UBRRL = (unsigned char) baud;
    
	// Enable receiver and tramsmitter
	UCSRB = (1<<RXEN)|(1<<TXEN);
    // Enable Interrupt
    UCSRB |= (1<<RXCIE)|(1<<TXCIE);
    // Set I-bit global interrupt enable
    sei();                  

	// Set frame format: 8data, NoneParity, 1stop bit
	UCSRC = (1<<URSEL)|(3<<UCSZ0);    
}

/*** Init_Serial */
void Init_Serial(unsigned int baudrate)
{    
    unsigned int baud;

    switch (baudrate) {
        case 96:
            baud = 51;      // baudrate to 9,600 bps using a 8MHz crystal
        default:
            baud = 51;
    }
    
    USART_Init( baud );  

}

/*** USART, Rx Complete Interrupt */
ISR (USART_RXC_vect)
{      
    c = UDR;    // Receive Data

    // Check connection
    if (c =='c') {
        conn = 1;
        return;
    } else if (c =='d') { 
        conn = 0; 
        return;
    } else if (c == 'l') {
        hookLED=1;
        return;    
    } else {
        // save led number
        if (hookLED) {
            iLED = c; 
            hookLED = 0;
            
        } else {
            // check status ON/OFF
            if (c) 
                sbi(PORTC,iLED);
            else 
                cbi(PORTC,iLED);

            // save led status
            sLED[iLED] = c;
        }
        return;
    }

    if (c == '\r') {
        UDR = '\n';         // New Line
        UDR = '\r';         // Return
        return;
    }
    
    loop_until_bit_is_set(UCSRA, UDRE);

    //UDR = c;                // Transmit Data
            
    return;
}

/*** USART, Tx Complete Interrupt */
ISR (USART_TXC_vect)
{  
    return;
}

