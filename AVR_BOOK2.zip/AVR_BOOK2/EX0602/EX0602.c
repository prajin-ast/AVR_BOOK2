/*-----------------------------------------
File      : EX0602.c
Purpose   : AVR + Visual BASIC Control
Compiler  : WinAVR Studio/WinAVR
Target    : ATmega16 
------------------------------------------*/

//----------------------------------------:INCLUDE

#include <avr/io.h>         // AVR device-specific IO definitions
#include <compat/deprecated.h>  // Use sbi(),cbi() function

#define F_CPU 8000000UL     // XTAL 8 MHz
#include <util/delay.h>     // header file implement simple delay loops

#include "LIB_iUART.c"      // Interrupt UART Module Library


//----------------------------------------:FUNCTION

// delay miliseconds
void delay_ms(uint16_t i)
{
  for (;i > 0; i--)
    _delay_ms(1);
}

// Send Status
void Send_Status(void)
{
  char buf[5];
  int i,adc_value;

  delay_ms(10);       // delay
  put_string("S");    // Start protocol
  delay_ms(10);       // delay

  // LED
  put_string("L");    
  for(i=0;i<=7;i++) {
    sprintf(buf,"%d%d,",i,sLED[i]);
    put_string(buf);
  }
  // Switch
  put_string("P");
  if((PINB&(1<<PINB0))==0) 
    put_string("1");
  else 
    put_string("0");

  if((PINB&(1<<PINB1))==0) 
    put_string("1");
  else 
    put_string("0");

  if((PINB&(1<<PINB2))==0) 
    put_string("1");
  else 
    put_string("0");

  if((PINB&(1<<PINB3))==0) 
    put_string("1");
  else 
    put_string("0");
    
  delay_ms(1);        // delay
        
  // ADC Start Conversion
  ADCSRA |= (1<<ADSC);    
  // Wait Conversion completes
  while (!(ADCSRA & (1<<ADIF)))    
    ;
  adc_value = ADCW;       // Read ADC

  put_string("A");    
  sprintf(buf,"%d",adc_value); // ADC result
  put_string(buf);
    
  delay_ms(10);       // delay        
  put_string("E");    // Stop protocol
  delay_ms(10);       // delay
}


//----------------------------------------:MAIN

int main(void)
{    
  // baudrate to 9,600 bps using a 8MHz crystal
  Init_Serial(96);

  // AVCC with external capacitor at AREF pin
  ADMUX = (0<<REFS1)|(1<<REFS0);
  // ADC Enable & auto Trigger Disable
  ADCSRA = (1<<ADEN)|(0<<ADATE);
  ADCSRA |= (0<<ADPS2)|(1<<ADPS1)|(1<<ADPS0);

  DDRC = 0xFF;        // LED: PORTC all output
  PORTC = 0x00;

  while (1) {
    if (conn) {     // connection
      Send_Status();
    }
      delay_ms(250);
  }

  return 0;
}

