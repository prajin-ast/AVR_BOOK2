/*-----------------------------------------
File      : EX0102.c
Purpose   : Switch Debounce
Compiler  : AVR Studio/WinAVR
Target    : ATmega16 
------------------------------------------*/

//----------------------------------------:INCLUDE

#include <avr/io.h>         // AVR device-specific IO definitions

#define F_CPU 8000000UL     // XTAL 8 MHz
#include <util/delay.h>     // header file implement simple delay loops

#define SW1 (PINB&(1<<PINB0))	// Key Switch

 
//----------------------------------------:FUNCTION

// delay miliseconds 
void delay_ms(uint16_t i)
{
  for (;i > 0; i--)
    _delay_ms(1);
}


//----------------------------------------:MAIN

int main(void)
{
  unsigned char count = 0;
    
  DDRA = 0xff;        // set port output
  PORTA = 0;          // clear port

  while (1) {         // loop forever
    if (!SW1) {       // wait key down  
      delay_ms(20);   // delay bounce
      if(!SW1)        // check key again
        count++;      // increment count
      while (SW1);    // wait for key up
    } else {
      PORTA = count;  // display count
    }		
  }

  return 0;
}
