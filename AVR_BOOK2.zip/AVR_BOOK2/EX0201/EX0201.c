/*-----------------------------------------
File      : EX0201.c
Purpose   : 8-Bit Parallel-Load Shift Register
Compiler  : AVR Studio/WinAVR
Target    : ATmega16 
------------------------------------------*/

//----------------------------------------:INCLUDE

#include <avr/io.h>         // AVR device-specific IO definitions
#include <compat/deprecated.h>  // Use sbi(),cbi() function

#define F_CPU 8000000UL     // XTAL 8 MHz
#include <util/delay.h>     // header file implement simple delay loops

#define DDR_SR      DDRA    // direction port shift register
#define PORT_OUT_SR PORTA   // output port
#define PORT_IN_SR  PINA    // input port

#define SH_PIN      PA0     // asynchronous parallel load input
#define CLK_PIN     PA1     // clock input (LOW-to-HIGH edge-triggered)
#define QH_PIN      PA2     // serial output from the last stage

#define SET_INP(x)      cbi(DDR_SR,x)
#define SET_OUTP(x)     sbi(DDR_SR,x)

#define SET_P(x)        sbi(PORT_OUT_SR,x)
#define CLS_P(x)        cbi(PORT_OUT_SR,x)
#define READ_P(x)       (PORT_IN_SR&(1<<x))


//----------------------------------------:NOTE
/*
 74HC/HCT165
 8-bit parallel-in/serial-out shift register
         ----
 SH/LD -|    |- Vcc
  CLK  -|    |- /CE
    E  -|    |- D
    F  -|    |- C
    G  -|    |- B
    H  -|    |- A
   /QH -|    |- Ds
   GND -|    |- QH
         ----
*/

//----------------------------------------:FUNCTION

// delay miliseconds
void delay_ms(uint16_t i)
{
  for (;i > 0; i--)
    _delay_ms(1);
}

// rotate left
uint8_t rotate_left(uint8_t *x, uint8_t i)
{
  for(;i>0;i--)
    *x = (*x>>1) | (*x<<7);

  return (*x);                         
}

// Serial Data input
unsigned char shift_in_data()
{
  unsigned char i;
  unsigned char dat=0x00;

  CLS_P(SH_PIN);            // parallel load   
  SET_P(SH_PIN);            // serial shift
 
	for(i=0;i<8;i++) {     
    dat |= READ_P(QH_PIN);  // data in
    
    rotate_left(&dat,1);    // rotate left

    CLS_P(CLK_PIN);         // clock pulse
 		SET_P(CLK_PIN);
 	}        
    
  rotate_left(&dat,2);      // rotate left

  return(dat);
}


//----------------------------------------:MAIN

int main(void)
{
  DDRB = 0xFF;                // set portb output

  SET_OUTP(SH_PIN);           // set output PL pin
  SET_OUTP(CLK_PIN);          // set output CP pin
  SET_INP(QH_PIN);            // set input QH pin

  while (1) {
    PORTB = shift_in_data();  // read data        
    delay_ms(1000);
  }

  return 0;
}
