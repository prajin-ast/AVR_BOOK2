/*-----------------------------------------
File      : EX1302.c
Purpose   : Ultrasonic
Compiler  : AVR Studio/WinAVR
Target    : ATmega128 
------------------------------------------*/

//----------------------------------------:INCLUDE

#include <avr/io.h>         // AVR device-specific IO definitions
#include <avr/interrupt.h>  // AVR interrupt
#include <compat/deprecated.h>  // Use sbi(), cbi() function

#define F_CPU 16000000UL    // XTAL 16 MHz
#include <util/delay.h>     // header file implement simple delay loops

#define LCD_PORTC           // Use PORTC for LCD Port
#include "LIB_LCD.C"        // LCD Library

#define SFR05_DDR     DDRF
#define TRIGGER_PORT  PORTF
#define TRIGGER_PIN   PINF0
#define ECHO_PIN      (PINF&(1<<PINF1))

unsigned int sec_count;

//----------------------------------------:FUNCTION

// delay_ms
void delay_ms(unsigned int i)
{        
  for (; i>0; i--)
    _delay_ms(1);
}

// Init Timer
void Init_Timer(void)
{
  // Timer/Counter1: CTC Mode with Prescaler 8
  TCCR1B = (1<<WGM12)|(0<<CS12)|(1<<CS11)|(0<<CS10);  
  // Set output compare 1A value to 2
  OCR1A = 2;
  // Global interrupt enable
  sei();
}

// trigger pulse for start process
void trigger_pulse(void)
{
  sbi(TRIGGER_PORT,TRIGGER_PIN);
  _delay_us(10);
  cbi(TRIGGER_PORT,TRIGGER_PIN);
}

// distance reading
unsigned int distance(void)
{  
  cbi(TRIGGER_PORT,TRIGGER_PIN);
  trigger_pulse();

  // Timer/Counter1, Output Compare A Match Flag
  TIFR = (1<<OCF1A);
  // Timer/Counter1, Output Compare A Match Interrupt Enable
  TIMSK = (1<<OCIE1A);

  while(!ECHO_PIN);     // Wait for start
  TCNT1 = 0;            // Clear Timer/Counter1 register
  sec_count = 0;        // Clear count
  while(ECHO_PIN);      // Wait for count

  // Timer/Counter1, Output Compare A Match Interrupt Disable
  TIMSK = (0<<OCIE1A);

  _delay_ms(10);
  return (sec_count/114);
}

//----------------------------------------:MAIN

int main(void)
{    
  unsigned int dis;

  Init_LCD();
  Init_Timer();
  	
  // PORTF0 output, PINF1 input
  SFR05_DDR = (0<<DDF1)|(1<<DDF0);

  LCD_PrintXY(1,1, 0, "Distance..");

  while (1) {	// Loop forever
  	dis = distance();
	  LCD_PutInt(1,2, dis);
    LCD_PrintXY(10,2, 0, "cm.");
	  delay_ms(500);
  }

  return 0;
}


//----------------------------------------:FUNCTION INTERRUPT

// Timer/Counter1 Compare Match A

ISR(TIMER1_COMPA_vect)
{   
  sec_count++;
}
