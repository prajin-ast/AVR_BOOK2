/*-----------------------------------------
File      : EX1302.c
Purpose   : Ultrasonic Distance Detector
Compiler  : AVR Studio/WinAVR
Target    : ATmega128 
------------------------------------------*/

//----------------------------------------:INCLUDE

#include <avr/io.h>         // AVR device-specific IO definitions
#include <avr/interrupt.h>  // AVR interrupt
#include <compat/deprecated.h>  // Use sbi(), cbi() function

#define F_CPU 16000000UL    // XTAL 16 MHz
#include <util/delay.h>     // header file implement simple delay loops

#define LCD_PORTC           // Use PORTC for LCD Port
#include "LIB_LCD.C"        // LCD Library

#define SRF05_DDR     DDRF
#define PULSE_PORT    PORTF
#define PULSE_PIN     PINF0
#define ECHO_PIN      (PINF&(1<<PINF1))


//----------------------------------------:FUNCTION

// delay_ms
void delay_ms(unsigned int i)
{        
  for (; i>0; i--)
    _delay_ms(1);
}

// Init Timer
void Init_Timer(void)
{
  // Timer/Counter1: Prescaler 8
  TCCR1B = (0<<CS12)|(1<<CS11)|(0<<CS10);  
}

// Trigger pulse for start process
void trigger_pulse(void)
{
  sbi(PULSE_PORT,PULSE_PIN);
  _delay_us(10);
  cbi(PULSE_PORT,PULSE_PIN);
}

// distance reading
unsigned int distance(void)
{  
  unsigned int ct;

  cbi(PULSE_PORT,PULSE_PIN);
  trigger_pulse();

  while(!ECHO_PIN);     // Wait for start
  TCNT1 = 0;            // Clear Timer/Counter1 register
  while(ECHO_PIN);      // Wait for count
  ct = TCNT1;
  
  _delay_ms(10);
  return (ct/114);
}

//----------------------------------------:MAIN

int main(void)
{    
  unsigned int dis, temp_dis=0;

  Init_LCD();
  Init_Timer();
  	
  // PORTF0 output, PINF1 input
  SRF05_DDR = (0<<DDF1)|(1<<DDF0);

  LCD_PrintXY(1,1, 0, "Ultrasonic test.");
  LCD_PrintXY(1,2, 0, "Dist:");

  while (1) {	// Loop forever
  	dis = distance();
    if (dis != temp_dis) {      
      LCD_PrintXY(7,2, 0, "    ");     // Clear
	    LCD_PutInt(7,2, dis);            // Put integer
      LCD_PrintXY(12,2, 0, "cm.");
      temp_dis = dis;
      delay_ms(1000);
    }	  
  }

  return 0;
}
