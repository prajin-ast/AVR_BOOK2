/*-----------------------------------------
File      : EX0105.c
Purpose   : Return statements
Compiler  : AVR Studio/WinAVR
Target    : ATmega16 
------------------------------------------*/

//----------------------------------------:INCLUDE

#include <avr/io.h>         // AVR device-specific IO definitions

#define F_CPU 8000000UL     // XTAL 8 MHz
#include <util/delay.h>     // header file implement simple delay loops


//----------------------------------------:FUNCTION

// delay miliseconds
void delay_ms(uint16_t i)
{
  for (;i > 0; i--)
    _delay_ms(1);
}

// rotate left
uint8_t rotate_left(uint8_t *x, uint8_t i)
{
  for(;i>0;i--)
    *x = (*x<<1) | (*x>>7);
 
  return (*x);                         
}

// led rotate
void led_rotate(void)
{
  unsigned char count = 0;
  unsigned char rl = 0x80;

  while (1) {
    count++;              // increment count
    rotate_left(&rl,1);   // rotate left
    
    if (count > 20)   
      return;             // exit function

    PORTA = rl;           // output porta
    delay_ms(500);        // delay
  }        
    
  PORTA = 0xFF;           // output porta
  delay_ms(1000);         // delay
}


//----------------------------------------:MAIN

int main(void)
{    
  DDRA = 0xff;          // set port output
  PORTA = 0;            // clear port

  led_rotate();         // function test "return"

  PORTA = 0xAA;         // on/off to alternate
  while (1)             // loop nothing
    ;

  return 0;
}
