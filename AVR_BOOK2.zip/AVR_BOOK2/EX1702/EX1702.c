/*-----------------------------------------
File      : EX1702.c
Purpose   : Bit&Bit-test (Inline ASM)
Compiler  : AVR Studio/WinAVR
Target    : ATmega128 
------------------------------------------*/

//----------------------------------------:INCLUDE

#include <avr/io.h>         // AVR device-specific IO definitions
#include <compat/deprecated.h>  // Use sbi(), cbi() function

#define F_CPU 16000000UL    // XTAL 16 MHz
#include <util/delay.h>     // header file implement simple delay loops

#define CR_TAB "\n\t"       // linefeed and tab


//----------------------------------------:FUNCTION

// delay_ms
void delay_ms(uint16_t i)
{
  for (;i > 0; i--)
    _delay_ms(1);         // this inline asm
}

//----------------------------------------:MAIN

int main(void)
{    
  register uint8_t i asm("r20");  // C Name Used in ASM Code

  DDRA = 0xFF;            // set PORTA output all
  i = 0x01;
  
  while (1) {             // loop forever
    PORTA = i;
    delay_ms(500);        // delay 0.5s
    // inline assembler
    asm volatile(
      "lsl r20" CR_TAB        // shift left
      "brcc nocarry" CR_TAB   // Branch if Carry Cleared
      "ldi r20, 0x01" CR_TAB  // Load Immediate
      "nocarry:" CR_TAB       // Label nocarry    
    );
  }

  return 0;
}
