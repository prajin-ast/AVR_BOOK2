/*-----------------------------------------
File      : EX1701.c
Purpose   : Inline-ASM Examples
Compiler  : AVR Studio/WinAVR
Target    : ATmega128 
------------------------------------------*/

//----------------------------------------:INCLUDE

#include <avr/io.h>         // AVR device-specific IO definitions
#include <compat/deprecated.h>  // Use sbi(), cbi() function

#define F_CPU 16000000UL    // XTAL 16 MHz
#include <util/delay.h>     // header file implement simple delay loops


//----------------------------------------:FUNCTION

// delay_ms
void delay_ms(uint16_t i)
{
  for (;i > 0; i--)
    _delay_ms(1);         // this inline asm
}

//----------------------------------------:MAIN

int main(void)
{    
  asm ("ser r20");        // Set Register
  asm ("out %0, r20"      // Set DDRA for OUTPUT 
        ::"I" (_SFR_IO_ADDR(DDRA)));

  while (1) {             // loop forever        
    asm ("com r20");      // One's Complement
    asm ("out %0,r20"     // Output PORTA
          ::"I" (_SFR_IO_ADDR(PORTA)));
    delay_ms(500);        // delay 0.5s
  }

  return 0;
}

