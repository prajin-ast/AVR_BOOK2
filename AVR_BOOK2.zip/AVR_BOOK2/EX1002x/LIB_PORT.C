/*
 ******************************************************************************
 * Workfile    : LIB_PORT.C
 * Purpose     : AVR PORT Library
 * Author      : Prajin Palangsantikul
 * Copyright   : appsofttech co.,ltd.
 * Compiler    : WinAVR Compiler
 * Target      : ATmega AVR MCU
 * Ref         :
 * Date        : 20/11/2006
 ******************************************************************************
*/


#if defined (__AVR_ATmega16__)
#include <avr/iom16.h>
#endif

/*
 ******************************************************************************
 * DEFINES
 ******************************************************************************
*/

/*** Bit Manipulation */
#define output_high(p, b) 	(p) |= (1 << (b))
#define output_low(p, b)	(p) &= ~(1 << (b))
#define output_toggle(p,b)	(!(p&(1<<b)) ? (output_high(p,b)):(output_low(p,b)))

#define input_bit(p,b)		(p&(1<<b)) 

/*** Byte Manipulation */
#define set_ddr_a(byte)     (DDRA = byte)
#define set_ddr_b(byte)     (DDRB = byte)
#define set_ddr_c(byte)     (DDRC = byte)
#define set_ddr_d(byte)     (DDRD = byte)

#define output_a(byte)      (PORTA = byte)
#define output_b(byte)      (PORTB = byte)
#define output_c(byte)      (PORTC = byte)
#define output_d(byte)      (PORTD = byte)

#define input_a(byte)       (PINA)
#define input_b(byte)       (PINB)
#define input_c(byte)       (PINC)
#define input_d(byte)       (PIND)


/*
 ******************************************************************************
 * FUNCTIONS
 ******************************************************************************
*/

/*** shift left */
uint8_t shift_left(uint8_t *x, uint8_t i)
{
    *x = *x<<i;
    return (*x);                         
}

/*** shift right */
uint8_t shift_right(uint8_t *x, uint8_t i)
{
    *x = *x>>i;

    return (*x);                         
}

/*** rotate left */
uint8_t rotate_left(uint8_t *x, uint8_t i)
{
    for(;i>0;i--)
        *x = (*x>>1) | (*x<<7);

    return (*x);                         
}

/*** rotate right */
uint8_t rotate_right(uint8_t *x, uint8_t i)
{
    for(;i>0;i--)
        *x = (*x<<1) | (*x>>7);

    return (*x);                         
}

/*** swap byte */
uint8_t swap_byte(uint8_t *x)
{
    *x = (*x<<4) | (*x>>4);

    return (*x);                         
}

/*** swap word */
uint16_t swap_word(uint16_t *x)
{
    *x = (*x<<8) | (*x>>8);

    return (*x);                         
}

/*** make 16 bit */
int16_t make_16bit(int8_t hi, int8_t lo)
{
    int16_t i=0;

    i = ((i|hi)<<8)|lo;

    return (i);
}

/*** make 32 bit */
int32_t make_32bit(int16_t var1, int16_t var2)
{
    int32_t i=0;

    i = ((i|var1)<<16)|(i|var2);

    return (i);
}
