/*-----------------------------------------
File      : EX1002x.c
Purpose   : Shift left/right
Compiler  : AVR Studio/WinAVR
Target    : ATmega128 
------------------------------------------*/

//----------------------------------------:INCLUDE

#include <avr/io.h>         // AVR device-specific IO definitions

#define F_CPU 8000000UL     // XTAL 8 MHz
#include <util/delay.h>     // header file implement simple delay loops

#include "LIB_PORT.C"     // PORT Library


//----------------------------------------:FUNCTION

// delay miliseconds
void delay_ms(uint16_t i)
{
  for (;i > 0; i--)
    _delay_ms(1);
}

//----------------------------------------:MAIN

int main(void)
{
  uint8_t n = 0x01;
  uint8_t i=1;

  set_ddr_a(0xFF);            // set PORTA output all

  while (1) {                 // loop forever            
    output_a(n);
    delay_ms(500);
    shift_left(&n,i);       // shift left
    output_a(n);
    delay_ms(500);
    shift_right(&n,i);      // shift right
    output_a(n);
    delay_ms(500);
    if (i++ >= 7) i = 1;     // set i to 1
  }

  return 0;
}
