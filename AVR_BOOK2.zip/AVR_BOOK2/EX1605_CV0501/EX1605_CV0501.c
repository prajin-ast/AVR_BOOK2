/*-----------------------------------------
File      : EX1605_CV0501.c
Purpose   : External Interrupt (INT0)
Compiler  : CodeVisionAVR
Target    : ATmega128 
------------------------------------------*/

//----------------------------------------:INCLUDE

#include <io.h>         // I/O registers definitions
#include <delay.h>      // Header file for Function Delay

//----------------------------------------:INTERRUPTS
               
// External Interrupt 0 service routine
interrupt [EXT_INT0] void ext_int0_isr(void)
{
    PORTA.0 = !PORTA.0; // Toggle bit
    delay_ms(200);
}

//----------------------------------------:MAIN

int main(void)
{  
    // External Interrupt(s) initialization
    // INT0: On (Port PD2)
    // INT0 Mode: Rising Edge
    // INT1: Off
    // INT2: Off
    GICR|=0x40;
    MCUCR=0x03;
    MCUCSR=0x00;
    GIFR=0x40;                         

    // Global enable interrupts
    #asm("sei")
    
    DDRA = 0x01;        // Set PA0 output
    PORTA.0 = 0;        // Clear PA0
                
    while (1) {         // Loop nothing
        ;
    }

    return 0;
}
