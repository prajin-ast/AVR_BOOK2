/*-----------------------------------------
File      : EX0901.c
Purpose   : ADC7, INT0 Trigger Source
Compiler  : AVR Studio/WinAVR
Target    : ATmega16 
------------------------------------------*/

//----------------------------------------:INCLUDE


#include <avr/io.h>         // AVR device-specific IO definitions
#include <avr/interrupt.h>  // Interrupt flag
#include <stdlib.h>         // Library for dtostrf() 

#define F_CPU 8000000UL     // XTAL 8 MHz
#include <util/delay.h>     // header file implement simple delay loops

#include "LIB_UART.C"       // UART Library

#define Vadc	1023        // 10-bit Resolution

//----------------------------------------:FUNCTION

// delay miliseconds
void delay_ms(uint16_t i)
{
	for (;i > 0; i--)
		_delay_ms(1);
}

//----------------------------------------:MAIN

int main(void)
{
	unsigned char r[5];
	float f;

	Init_Serial(96);				// Init Serial port  
        
  MCUCR = (1<<ISC01)|(1<<ISC00);  // Rising edge of INT0    
	GICR = (1<<INT0);               // Enable INT0 Interrupt
	sei();                          // Set Global Interrupt

	// AVCC with external capacitor at AREF pin
	ADMUX = (0<<REFS1)|(1<<REFS0);
	// Analog Channel ADC7
	ADMUX |= (0<<MUX4)|(0<<MUX3)|(1<<MUX2)|(1<<MUX1)|(1<<MUX0);
  // ADC Enable, Start & ADC Auto Trigger Enable
  ADCSRA = (1<<ADEN)|(1<<ADSC)|(1<<ADATE);  
  // ADC Prescaler (XTAL/8)
  ADCSRA |= (0<<ADPS2)|(1<<ADPS1)|(1<<ADPS0);	

  // INT0 Trigger Source
  SFIOR = (0<<ADTS2)|(1<<ADTS1)|(0<<ADTS0);   

  while (1) {

    // Wait Coversion completes
    while (!(ADCSRA &(1<<ADIF)))    
      ;
    
    // Convert float to string(used libm.a)
    f = (ADCW*5);
    f = (f/Vadc);
    dtostrf(f, 4, 2, r);

    printf("\fADC, Wait..INT0 Trigger Source "); 
    printf("\nADC7, Voltage: ");
    printf("%s V",r);       // Read ADC
    delay_ms(500);          // Delay 0.5s
  }

  return 0;
}


//----------------------------------------:INTERRUPT FUNCTION

// External Interrupt Request 0: INT0 (Port PD2)
ISR (INT0_vect)
{
  return;
}
