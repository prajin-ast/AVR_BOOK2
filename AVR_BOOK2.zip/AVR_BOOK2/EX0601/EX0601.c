/*-----------------------------------------
File      : EX0601.c
Purpose   : Protocal ABC Example
Compiler  : AVR Studio/WinAVR
Target    : ATmega16 
------------------------------------------*/

//----------------------------------------:INCLUDE

#include <avr/io.h>         // AVR device-specific IO definitions

#define F_CPU 8000000UL     // XTAL 8 MHz
#include <util/delay.h>     // header file implement simple delay loops

#include "LIB_UART.c"      // UART Module Library


//----------------------------------------:FUNCTION

// delay miliseconds
void delay_ms(uint16_t i)
{
  for (;i > 0; i--)
    _delay_ms(1);
}

// Wait show dot
void wait_dot(uint8_t n,uint16_t dly)
{
  for(;n>0;n--) {
    printf(".");    // print "."
    delay_ms(dly);  // delay
  }
}

//----------------------------------------:MAIN

int main(void)
{
  char buf[5];

  // baudrate to 9,600 bps using a 8MHz crystal
  Init_Serial(96);

  printf("\f");   // clear screen

  while (1) {
    printf("Wait connecting command: ");

    if (gets(buf) == NULL)
      break;
        
    switch(buf[0]) {
      case 'b':
        wait_dot(5,100);
        printf("Connected\r\n");
        break;

      case 'z':
        printf("Disconnected Goodbye\r\n");
        goto LBL_STOP;

      default:
        printf("Unknown command?\r\n");
    }
  }

LBL_STOP:
  while (1);  // loop noting

  return 0;
}
