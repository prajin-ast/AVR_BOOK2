/*
 ******************************************************************************
 * Workfile    : LIB_GLCD.C
 * Purpose     : AVR GLCD Library
 * Author      : Prajin Palangsantikul
 * Copyright   : appsofttech co.,ltd.
 * Compiler    : WinAVR Compiler
 * Target      : ATmega AVR MCU
 * Ref         : PIC C TGLCD Library
 * Date        : 26/03/2008
 ******************************************************************************
*/

/*** Note ***
* GLCD Pin connections:
* 1   : VSS     to GND
* 2   : VDD     to +5V
* 3   : V0      to VR  (Constrast adjustment)
* 4   : RS      to PA0
* 5   : R/W     to PA1
* 6   : E       to PA2
* 7-14: DB0-DB7 to PORTC
* 15  : CS1     to PA3
* 16  : CS2     to PA4
* 17  : RST     to PA5
* 18  : VEE     to 20k Ohm POT
* 19  : A       to +5V (Positive voltage for LED backlight)
* 20  : K       to GND (Negavtive voltage for LED backlight)
*/

#define GLCD_WIDTH        128

#define GLCD_DATA_DDR     DDRC    // Data Bus 0 to 7
#define GLCD_DATA_PORT    PORTC
#define GLCD_DATA_PIN     PINC

#define GLCD_CTRL_DDR     DDRA    // Control Bus
#define GLCD_CTRL_PORT    PORTA

#define GLCD_CTRL_RS      PA0     // Data or Instruction input
#define GLCD_CTRL_RW      PA1     // Read/Write
#define GLCD_CTRL_E       PA2     // Enable
#define GLCD_CTRL_CS1     PA3     // Chip Selection 1
#define GLCD_CTRL_CS2     PA4     // Chip Selection 2
#define GLCD_CTRL_RST     PA5     // Reset

#define GLCD_LEFT         0
#define GLCD_RIGHT        1
#define ON                1
#define OFF               0

#define outp(port, val) (port) = (val)

/*** Function Prototypes */
void delay_cycles(char cy);
void GLCD_init(char mode);
void GLCD_pixel(char x, char y, char color);
void GLCD_fillScreen(char color);
void GLCD_writeByte(char side, char data);
char GLCD_readByte(char side);


/*** Delay cycle */ 
void delay_cycles(char cy) 
{
  for(;cy>0;cy--)
    asm volatile ("nop");
}  

/*** Initialize the LCD. */ 
void GLCD_init(char mode)
{
   
  outp(GLCD_CTRL_DDR,0xFF);              // Set port output

  // Initialze some pins
  sbi(GLCD_CTRL_PORT,GLCD_CTRL_RST);
  cbi(GLCD_CTRL_PORT,GLCD_CTRL_E);
  cbi(GLCD_CTRL_PORT,GLCD_CTRL_CS1);
  cbi(GLCD_CTRL_PORT,GLCD_CTRL_CS2);

  cbi(GLCD_CTRL_PORT,GLCD_CTRL_RS);    // Set for instruction
  GLCD_writeByte(GLCD_LEFT,  0xC0);    // Specify first RAM line at the top
  GLCD_writeByte(GLCD_RIGHT, 0xC0);    // of the screen
  GLCD_writeByte(GLCD_LEFT,  0x40);    // Set the column address to 0
  GLCD_writeByte(GLCD_RIGHT, 0x40);
  GLCD_writeByte(GLCD_LEFT,  0xB8);    // Set the page address to 0
  GLCD_writeByte(GLCD_RIGHT, 0xB8);

  if(mode == ON)
  {
     GLCD_writeByte(GLCD_LEFT,  0x3F); // Turn the display on
     GLCD_writeByte(GLCD_RIGHT, 0x3F);
  }
  else
  {
     GLCD_writeByte(GLCD_LEFT,  0x3E); // Turn the display off
     GLCD_writeByte(GLCD_RIGHT, 0x3E);
  }

  GLCD_fillScreen(OFF);                // Clear the display

}

/*** Turn a pixel on a graphic LCD on or off */
void GLCD_pixel(char x, char y, char color)
{
  char data;
  char side = GLCD_LEFT;  // Stores which chip to use on the LCD


  if(x > 63)              // Check for first or second display area
  {
     x -= 64;
     side = GLCD_RIGHT;
  }

  cbi(GLCD_CTRL_PORT,GLCD_CTRL_RS);           // Set for instruction
  cbi(x,7);                                   // Clear the MSB. Part of an instruction code
  sbi(x,6);                                   // Set bit 6. Also part of an instruction code
  GLCD_writeByte(side, x);                    // Set the horizontal address
  GLCD_writeByte(side, ((y/8) & 0xBF) | 0xB8);  // Set the vertical page address
  sbi(GLCD_CTRL_PORT,GLCD_CTRL_RS);           // Set for data
  GLCD_readByte(side);                        // Need two reads to get data
  data = GLCD_readByte(side);                 //  at new address

  if(color == ON)
     sbi(data, y%8);                          // Turn the pixel on
  else                                        // or
     cbi(data, y%8);                          // turn the pixel off

  cbi(GLCD_CTRL_PORT,GLCD_CTRL_RS);           // Set for instruction
  GLCD_writeByte(side, x);                    // Set the horizontal address
  sbi(GLCD_CTRL_PORT,GLCD_CTRL_RS);           // Set for data
  GLCD_writeByte(side, data);                 // Write the pixel data
}

/*** Fill the LCD screen with the passed in color */
void GLCD_fillScreen(char color)
{
  char i, j;

  // Loop through the vertical pages
  for(i = 0; i < 8; ++i)
  {
     cbi(GLCD_CTRL_PORT,GLCD_CTRL_RS);          // Set for instruction
     GLCD_writeByte(GLCD_LEFT, 0x40);           // Set horizontal address to 0
     GLCD_writeByte(GLCD_RIGHT, 0x40);
     GLCD_writeByte(GLCD_LEFT, i | 0xB8);       // Set page address
     GLCD_writeByte(GLCD_RIGHT, i | 0xB8);
     sbi(GLCD_CTRL_PORT,GLCD_CTRL_RS);          // Set for data

     // Loop through the horizontal sections
     for(j = 0; j < 64; ++j)
     {
        GLCD_writeByte(GLCD_LEFT, 0xFF*color);  // Turn pixels on or off
        GLCD_writeByte(GLCD_RIGHT, 0xFF*color); // Turn pixels on or off
     }
  }
}


/*** Write a byte of data to the specified chip */
void GLCD_writeByte(char side, char data)
{  
  outp(GLCD_DATA_DDR,0xFF);             // Set port d to output  
  delay_cycles(20);                     //*** wait GLCD ready
      
  if(side)                              // Choose which side to write to
    sbi(GLCD_CTRL_PORT,GLCD_CTRL_CS2);
  else
    sbi(GLCD_CTRL_PORT,GLCD_CTRL_CS1);

  cbi(GLCD_CTRL_PORT,GLCD_CTRL_RW);     // Set for writing
  outp(GLCD_DATA_PORT,data);            // Put the data on the port
  delay_cycles(1);

  sbi(GLCD_CTRL_PORT,GLCD_CTRL_E);      // Pulse the enable pin
  delay_cycles(5);	
  cbi(GLCD_CTRL_PORT,GLCD_CTRL_E);

  cbi(GLCD_CTRL_PORT,GLCD_CTRL_CS1);    // Reset the chip select lines
  cbi(GLCD_CTRL_PORT,GLCD_CTRL_CS2);
}

/*** Reads a byte of data from the specified chip */
char GLCD_readByte(char side)
{
  char data;                              // Stores the data read from the LCD
  
  outp(GLCD_DATA_DDR,0x00);               // Set port to input  
  delay_cycles(20);                       //*** wait GLCD ready

  sbi(GLCD_CTRL_PORT,GLCD_CTRL_RW);       // Set for reading

  if(side)                                // Choose which side to write to
     sbi(GLCD_CTRL_PORT,GLCD_CTRL_CS2);
  else
     sbi(GLCD_CTRL_PORT,GLCD_CTRL_CS1);

  delay_cycles(1);
  sbi(GLCD_CTRL_PORT,GLCD_CTRL_E);        // Pulse the enable pin
  delay_cycles(4);
  data = inp(GLCD_DATA_PIN);              // Get the data from the display's output register
  cbi(GLCD_CTRL_PORT,GLCD_CTRL_E);

  cbi(GLCD_CTRL_PORT,GLCD_CTRL_CS1);      // Reset the chip select lines
  cbi(GLCD_CTRL_PORT,GLCD_CTRL_CS2);
  
  return data;                            // Return the read data
}

