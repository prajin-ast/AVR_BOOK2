/*
 ******************************************************************************
 * Workfile    : LIB_TGLCD.C
 * Purpose     : AVR Thai GLCD Library
 * Author      : Prajin Palangsantikul
 * Copyright   : appsofttech co.,ltd.
 * Compiler    : WinAVR Compiler
 * Target      : ATmega AVR MCU
 * Ref         : 
 * Date        : 26/03/2008
 ******************************************************************************
*/

#include <ctype.h>

#define SP_FONT  7    // Space font

void TGLCD_putbitmap(char x, char y, unsigned char ascii);
void TGLCD_thaixy(char column, char row, unsigned char *content);

/*** Put bitmap */
void TGLCD_putbitmap(char x, char y, unsigned char ascii)
{
	unsigned char bitmap[8] = { 0x80, 0x40, 0x20, 0x10, 0x08, 0x04, 0x02, 0x01 };
  register char x1, y1;
  unsigned char ch;

	for( y1=0; y1<16; y1++)
  {
    ch = (unsigned char) pgm_read_dword_near(&font[ascii][y1]);
		for(x1=0; x1<8; x1++) 
    {      
			if( (ch & bitmap[x1] ) != 0)
        GLCD_pixel((x+x1), (y+y1), 1);        
    }
  }
}

/*** Thai X,Y */
void TGLCD_thaixy(char column, char row, unsigned char *content)
{
	char k ,ypix, xpix;
	unsigned char asc;

//	column=(column-1)*8;
//	row=(row-1)*16;

	for(k=0; k<strlen(content); k++)
	{
		ypix=0; xpix=0;
		if(tolower(content[k]) > 160) asc = tolower(content[k]);
		else asc = toascii(content[k]);
		if(asc==209) { xpix = -6; }
		if((asc>215) & (asc<219)) { xpix = -SP_FONT; }
		if((asc>211) & (asc<216)) { xpix = -SP_FONT; }
		if((asc>230) & (asc<239)) { ypix = +1; xpix = -SP_FONT; }

		TGLCD_putbitmap(column+xpix, row+ypix, asc);

		if(asc<209) column +=SP_FONT;
		if((asc>209) & (asc<212)) column +=SP_FONT;
		if((asc>223) & (asc<231)) column +=SP_FONT;
		if((asc>239) & (asc<250)) column +=SP_FONT;
	}
}
