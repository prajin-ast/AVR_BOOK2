/*-----------------------------------------
File      : EX1802.c
Purpose   : Thai GLCD128x64 Demo
Compiler  : AVR Studio/WinAVR
Target    : ATmega128 
------------------------------------------*/

//----------------------------------------:INCLUDE

#include <avr/io.h>         // AVR device-specific IO definitions
#include <compat/deprecated.h>  // Use sbi(), cbi() function
#include <avr/pgmspace.h>   // Program spaceString Utilities

#define F_CPU 16000000UL    // XTAL 16 MHz
#include <util/delay.h>     // header file implement simple delay loops

#include "jFont8x16.dat"    // JIN Font (Ref..Thai Font 8x16 (VTHAI.FONT))

#include "LIB_GLCD.C"       // AVR GLCD Library
#include "LIB_GGLCD.C"      // AVR Graphics GLCD Library
#include "LIB_TGLCD.C"      // AVR Thai GLCD Library


int main(void)
{
  GLCD_init(ON);          // Init
  GLCD_fillScreen(0);     // Clear Screen

  TGLCD_thaixy(10, 0, "�����¡Ѻ TGLCD");  // Display 
  TGLCD_thaixy(15,15, "C �Ѻ AVR ���� 2");
  TGLCD_thaixy(30,30, "�;�Ϳ��෤");
  TGLCD_thaixy( 5,45, "-- APPSOFTTECH --");

  while(1)
    ;

	return 0;
}
