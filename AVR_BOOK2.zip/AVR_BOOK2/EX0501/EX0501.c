/*-----------------------------------------
File      : EX0501.c
Purpose   : Remote 8-Bit I/O expander for I2C Bus
Compiler  : AVR Studio/WinAVR
Target    : ATmega16 
------------------------------------------*/

//----------------------------------------:INCLUDE

#include <avr/io.h>         // AVR device-specific IO definitions
#include <compat/deprecated.h>  // Use sbi(),cbi() function

#define F_CPU 8000000UL     // XTAL 8 MHz
#include <util/delay.h>     // header file implement simple delay loops

//----------------------------------------:I2C PIN

#define DDR_I2C         DDRA    // direction port shift register
#define PORT_OUT_I2C    PORTA   // output port
#define PORT_IN_I2C     PINA    // input port
#define SDA             PA0     // I2C Data	(SDA pin)
#define SCL             PA1     // I2C Clock(SCL pin)

#define CONTROL_CODE    0x70    // Control byte PCF8574A:0111[A2A1A0]0
#include "LIB_I2C_J.c"          // I2C Module Library

uint8_t deviceAddress;          // deviceAddress

//----------------------------------------:NOTE
/* 
 PCF8574A:Remote 8-bit I/O expander for I2C Bus
        ----
   A0 -|    |- Vdd
   A1 -|    |- SDA
   A2 -|    |- SCL
   P0 -|    |- /INT
   P1 -|    |- P7
   P2 -|    |- P6
   P3 -|    |- P5
  GND -|    |- P4
        ----
*/


//----------------------------------------:FUNCTION

// delay miliseconds
void delay_ms(uint16_t i)
{
  for (;i > 0; i--)
    _delay_ms(1);
}

// Setup chipAddress
// chipAddress the binary address value of the new PCF8574A chip.
// This should be the binary value of A2, A1, A0.
void PCF8574A(uint8_t chipAddress) 
{
  deviceAddress = ((CONTROL_CODE | (chipAddress << 1)) & 0xFF);
}

// PCF8574A read
uint8_t PCF8574A_Read(void) 
{
  uint8_t controlByte = deviceAddress | READ_BIT;
  uint8_t value;

  i2c_start();
  i2c_write(controlByte);
  value = i2c_read(NAK);
  i2c_stop();

  return value;
}

// PCF8574A write
void PCF8574A_Write(uint8_t dataByte) 
{
  uint8_t controlByte = deviceAddress | WRITE_BIT;

  i2c_start();
  i2c_write(controlByte);
  i2c_write(dataByte);
  i2c_stop();

  delay_ms(10);       // Secure wait for the write cycle
}

// PCF8574A I/O
void PCF8574A_IO_Expander(void)
{	
  uint8_t dat;

  dat = PCF8574A_Read();  // Read data
  dat = (dat>>4) | 0xF0;  // Set bit to write
  PCF8574A_Write(dat);	// Write data
  delay_ms(10);
}


//----------------------------------------:MAIN

int main(void)
{	
  // PCF8574A: input P4-P7, output P0-P3
  // slave address : 0
  PCF8574A(0);            

  while (1) {
    PCF8574A_IO_Expander();
  }

  return 0;
}
