/*
 ******************************************************************************
 * Workfile    : LIB_I2C_J.c
 * Purpose     : I2C Library
 * Author      : Prajin Palangsantikul
 * Company     : appsofttech co.,ltd.
 * Compiler    : WinAVR Compiler
 * Target      : ATmega AVR MCU
 * Ref         : 
 * Date        : 03/06/07
 ******************************************************************************
*/

/*
 ******************************************************************************
 * DEFINES
 ******************************************************************************
*/

#define READ_BIT        1       // Read Mode
#define WRITE_BIT       0       // Write Mode

/*
 * Ack/NAck condition can be detected by the write method or
 * transmitted by the read method.
*/

#define ACK             0       // Acknowledgement
#define NAK             1       // No acknowledgement

#define POST_CLK_LSB    1       // Post-clock sampling and LSB-first trasmission
#define POST_CLK_MSB    2       // Post-clock sampling and MSB-first trasmission
#define PRE_CLK_LSB     3       // Pre-clock sampling and LSB-first trasmission
#define PRE_CLK_MSB     4       // Pre-clock sampling and MSB-first trasmission

#define SHIFT_LSB       1       // Shift LSB first
#define SHIFT_MSB       2       // Shift MSB first

#define sdaPin          SDA     // pins for I2C bus
#define sclPin          SCL

#define SET_INP(x)      cbi(DDR_I2C,x)
#define SET_OUTP(x)     sbi(DDR_I2C,x)

#define SET_P(x)        sbi(PORT_OUT_I2C,x)
#define CLS_P(x)        cbi(PORT_OUT_I2C,x)
#define READ_P(x)       (PORT_IN_I2C&(1<<x))

#define nop()           asm volatile("nop");

#define i2c_ClkH()      {nop();nop();nop();nop();nop();nop();nop();nop();nop();nop();}
#define i2c_ClkL()      {nop();nop();nop();nop();nop();}
#define i2c_Wait()      {nop();nop();nop();nop();nop();}

/*
 ******************************************************************************
 * FUNCTIONS
 ******************************************************************************
*/

/*** rotate left */
uint8_t rotate_left(uint8_t *x, uint8_t i)
{
    for(;i>0;i--)
        *x = (*x>>1) | (*x<<7);

    return (*x);                         
}

/*** rotate right */
uint8_t rotate_right(uint8_t *x, uint8_t i)
{
    for(;i>0;i--)
        *x = (*x<<1) | (*x>>7);

    return (*x);                         
}

/*
 ******************************************************************************
 * I2C FUNCTIONS
 ******************************************************************************
*/

/*** Creates I2C bus object and intializes bus pins. */
void i2c_init(void)
{
    SET_OUTP(sdaPin);   // set output port       
    SET_OUTP(sclPin);

    SET_P(sdaPin);      // release bus pins to pull-ups
    SET_P(sclPin);
}

/*** Send I2C Start sequence. */
void i2c_start() 
{
    i2c_init();     // init I2C

    CLS_P(sdaPin);  // take SDA low first        
    i2c_Wait();     // wait for clock hold to release
    CLS_P(sclPin);  // setup for high-going clock pulse
}

/*** Send I2C Stop sequence. */
void i2c_stop() 
{
    CLS_P(sdaPin);  // make sure SDA is low
    SET_P(sclPin);  // let SCL pin go high first
    SET_P(sdaPin);
}

/*** Shift in data */
uint8_t shiftIn(uint8_t bitCount, uint8_t mode )
{
    uint8_t i2cData=0x00;
    
    SET_INP(sdaPin);    // set input port

    for(;bitCount>0;bitCount--) {
        if (mode == PRE_CLK_MSB) {
            rotate_left(&i2cData,1);
        }
        if (mode == PRE_CLK_LSB) {
            rotate_right(&i2cData,1);
        }
        
        // Read SDA
        i2cData |= READ_P(sdaPin);

        SET_P(sclPin);  // Clock
        i2c_ClkL();        
        CLS_P(sclPin);
        i2c_ClkH();
     }

    SET_OUTP(sdaPin);   // set output port

    return (i2cData);
}

/*** Shift out data */
void shiftOut(uint8_t bitCount, uint8_t mode, uint8_t i2cData)
{    
    CLS_P(sclPin);

    for (;bitCount>0;bitCount--) {
        if (mode == SHIFT_MSB) {
            rotate_left(&i2cData,1);    // Set SDA to value of MSB
        }
        if (mode == SHIFT_LSB) {
            rotate_right(&i2cData,1);   // Set SDA to value of LSB
        }

        if(i2cData&0x01) {
            SET_P(sdaPin);  // SDA High
        } else {
            CLS_P(sdaPin);  // SDA Low
        }

        SET_P(sclPin);      // Clock          
        i2c_ClkH();
        CLS_P(sclPin);
        i2c_ClkL();
    }
}

/*** Write 8-bit value to I2C device. */
// @param i2cData Value to write to I2C device.
// @return True if device returned Ack; False if Nak.
uint8_t i2c_write(uint8_t i2cData) 
{
    uint8_t i2cAck;

    shiftOut(8, SHIFT_LSB, i2cData);
    // get Ack bit
    i2cAck = shiftIn(1, PRE_CLK_MSB);

    return (i2cAck);
}

/*** Read 8-bit value from I2C device. */
// @param ackBit 0 to send Ack; 1 to send Nak after receipt of data.
// @return Value from I2C device.
uint8_t i2c_read(uint8_t ackBit) 
{
    uint8_t i2cData;

    i2cData = shiftIn(8, PRE_CLK_LSB);
    // send Ack (more reads) or Nak (last read)
    if (ackBit == ACK)
        shiftOut(1, SHIFT_LSB, ackBit);

    return i2cData;
}
