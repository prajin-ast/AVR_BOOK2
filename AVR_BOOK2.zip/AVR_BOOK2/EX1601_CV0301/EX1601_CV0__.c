/*-----------------------------------------
File      : EX1601_CV0301.c
Purpose   : One Switch/Three LED RTOS Demo
Compiler  : CodeVisionAVR
Target    : ATmega128
------------------------------------------*/

//----------------------------------------:INCLUDE

#include <io.h>     // I/O registers definitions
	#ifndef __SLEEP_DEFINED__
	#define __SLEEP_DEFINED__
	.EQU __se_bit=0x20
	.EQU __sm_mask=0x1C
	.EQU __sm_powerdown=0x10
	.EQU __sm_powersave=0x18
	.EQU __sm_standby=0x14
	.EQU __sm_ext_standby=0x1C
	.EQU __sm_adc_noise_red=0x08
	.SET power_ctrl_reg=mcucr
	#endif

//----------------------------------------:MAIN

int main(void)
{
    DDRA=0xFF;          // PORT A Output all
    PORTA=0x00;         // Clear port

    PORTA = 0x01;       // Output high PA0

    while (1)           // Loop nothing
        ;

    return 0;
}
