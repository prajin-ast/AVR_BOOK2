/*-----------------------------------------
File      : EX1601_CV0301.c
Purpose   : PORTA Output (PA0)
Compiler  : CodeVisionAVR
Target    : ATmega128 
------------------------------------------*/

//----------------------------------------:INCLUDE

#include <io.h>     // I/O registers definitions

//----------------------------------------:MAIN

int main(void)
{  
    DDRA=0xFF;          // PORT A Output all
    PORTA=0x00         // Clear port
    
    PORTA = 0x01;       // Output high PA0
            
    while (1)           // Loop nothing
        ;

    return 0;
}
