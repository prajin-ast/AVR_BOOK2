/*-----------------------------------------
File      : EX1503.c
Purpose   : One Port/Two Bit LED RTOS Demo
Compiler  : AVR Studio/WinAVR
Target    : ATmega128 
------------------------------------------*/

//----------------------------------------:INCLUDE

// Scheduler include files.
#include "FreeRTOS.h"		
#include "task.h"

// Priority definitions for most of the tasks in the demo application.
// Some tasks just use the idle priority.
#define TASK1_PRIORITY		(tskIDLE_PRIORITY + 1)
#define TASK2_PRIORITY		(tskIDLE_PRIORITY + 2)
#define TASK3_PRIORITY		(tskIDLE_PRIORITY + 3)

// Constant data for I/O
#define ALL_BITS_OUTPUT		((unsigned portCHAR) 0xff)
#define ALL_OUTPUTS_OFF		((unsigned portCHAR) 0x00)
#define MAX_OUTPUT_LED      ((unsigned portCHAR) 7)

// Bit Manipulation
#define output_high(p, b) 	(p) |= (1 << (b))
#define output_low(p, b)	(p) &= ~(1 << (b))
#define output_toggle(p,b)	(!(p&(1<<b)) ? (output_high(p,b)):(output_low(p,b)))


//----------------------------------------:FUNCTION

// Initialise Port
void InitialisePort(void)
{
	unsigned portCHAR ucCurrentOutputValue = 0x00;

	// Set Port A/B direction to outputs.
	DDRA = ALL_BITS_OUTPUT;
	PORTA = ucCurrentOutputValue;
    
	DDRB = ALL_BITS_OUTPUT;
	PORTB = ucCurrentOutputValue;
}


//----------------------------------------:TASK

// TASK Shift LED
void Task_ShiftLED(void * pvParameters)
{
  // Perform an action every 1000 ticks.
	const portTickType xFrequency = 1000;
 	portTickType xLastWakeTime;
  unsigned char i=0;

  // Initialise the xLastWakeTime variable with the current time.
  xLastWakeTime = xTaskGetTickCount();

  for (;;) {
    // Wait for the next cycle.
    vTaskDelayUntil(&xLastWakeTime, xFrequency);        
    PORTA = ~(i);      // Output 
    i = i<<1;
    if (i <= 0x00) i = 0x01;
  }
 }

// TASK Toggle LED 1
void Task_ToggleLED1(void * pvParameters)
{
  // Perform an action every 1000 ticks..
  const portTickType xFrequency = 1000;
  portTickType xLastWakeTime;

  // Initialise the xLastWakeTime variable with the current time.
  xLastWakeTime = xTaskGetTickCount();

  for (;;) {
    // Wait for the next cycle.
    vTaskDelayUntil(&xLastWakeTime, xFrequency);
    output_toggle(PORTB,0);
  } 
}

// TASK Toggle LED 2
void Task_ToggleLED2(void * pvParameters)
{
  // Perform an action every 1000 ticks.
  const portTickType xFrequency = 1000;     
  portTickType xLastWakeTime;

  // Initialise the xLastWakeTime variable with the current time.
  xLastWakeTime = xTaskGetTickCount();

  for (;;) {
    // Wait for the next cycle.
    vTaskDelayUntil(&xLastWakeTime, xFrequency);
    output_toggle(PORTB,1);
  } 
}

//----------------------------------------:MAIN

portSHORT main(void)
{
  InitialisePort();

  // Create the task, storing the handle.
  xTaskCreate(Task_ShiftLED,  "Task1", configMINIMAL_STACK_SIZE, NULL, TASK1_PRIORITY, NULL);
  xTaskCreate(Task_ToggleLED1,"Task2", configMINIMAL_STACK_SIZE, NULL, TASK2_PRIORITY, NULL);
  xTaskCreate(Task_ToggleLED2,"Task3", configMINIMAL_STACK_SIZE, NULL, TASK2_PRIORITY, NULL);
		
  // In this port, to use preemptive scheduler define configUSE_PREEMPTION 
  // as 1 in portmacro.h.  To use the cooperative scheduler define 
  // configUSE_PREEMPTION as 0.
  vTaskStartScheduler();

  return 0;
}
