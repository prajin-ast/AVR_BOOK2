/*-----------------------------------------
File      : EX0502.c
Purpose   : 24xx128 Serial EEPROM
Compiler  : AVR Studio/WinAVR
Target    : ATmega16 
------------------------------------------*/

//----------------------------------------:INCLUDE

#include <avr/io.h>         // AVR device-specific IO definitions
#include <compat/deprecated.h>  // Use sbi(),cbi() function

#define F_CPU 8000000UL     // XTAL 8 MHz
#include <util/delay.h>     // header file implement simple delay loops

#include "LIB_UART.c"           // UART Module Library

//----------------------------------------:I2C PIN
#define DDR_I2C         DDRA    // direction port shift register
#define PORT_OUT_I2C    PORTA   // output port
#define PORT_IN_I2C     PINA    // input port
#define SDA             PA0     // I2C Data	(SDA pin)
#define SCL             PA1     // I2C Clock(SCL pin)

#define CONTROL_CODE    0xA0    // Control byte :1010[A2A1A0]0
#include "LIB_I2C_J.c"          // I2C Module Library

uint8_t deviceAddress;          // deviceAddress

//----------------------------------------:NOTE
/* 
 24xx128: Serial EEPROM
        ----
   A0 -|    |- Vcc
   A1 -|    |- WP
   A2 -|    |- SCL
  Vss -|    |- SDA
        ----
*/


//----------------------------------------:FUNCTION

// delay miliseconds
void delay_ms(uint16_t i)
{
  for (;i > 0; i--)
    _delay_ms(1);
}

// Setup chipAddress
// chipAddress the binary address value of the new 24xx128 chip.
// This should be the binary value of A2, A1, A0.
void EE24xx128(uint8_t chipAddress) 
{
  deviceAddress = ((CONTROL_CODE | (chipAddress << 1)) & 0xFF);
}

// EEPROM_Read
uint8_t EEPROM_Read(uint16_t adr)
{
  uint8_t controlByte, dat;

  controlByte = deviceAddress | WRITE_BIT;

  i2c_start();            // start condition     
  i2c_write(controlByte); // control byte read
  i2c_write(adr>>8);      // address High Byte
  i2c_write(adr);         // address Low Byte

  controlByte = deviceAddress | READ_BIT;

  i2c_start();            // start condition     
  i2c_write(controlByte); // control byte read
  dat = i2c_read(NAK);    // NACK Received
        
  i2c_stop();             // stop condition

  return (dat);
}

// EEPROM_Write
void EEPROM_Write(uint16_t adr,uint8_t dat)
{
  uint8_t controlByte = deviceAddress | WRITE_BIT;

  i2c_start();            // start condition 
  i2c_write(controlByte); // control byte write    
  i2c_write(adr>>8);      // address High Byte
  i2c_write(adr);         // address Low Byte

  i2c_write(dat);         // data byte

  i2c_stop();             // stop condition
}


//----------------------------------------:MAIN

int main(void)
{       
  uint16_t ee_adr;
  uint8_t dat=0x01;
	
  // 24xx128 slave address : 0
  EE24xx128(0); 

  Init_Serial(96);      // Init Serial port

  printf("\f24xx128 Serial EEPROM Write/Read");

  for (ee_adr=0x0000; ee_adr<=0x000F; ee_adr++) {
    // Write data
    EEPROM_Write(ee_adr,dat++);		
    // Wait for write-cycle time (5 ms max)
    _delay_ms(5);
  }

  printf("\nWrite EEPROM Complete...");

  for (ee_adr=0x0000; ee_adr<=0x000F; ee_adr++) {
    printf("\nRead EEPROM @%X data: %d",
    ee_adr,EEPROM_Read(ee_adr));
  }

  while (1);			// Loop Nothing

  return 0;
}
