/*-----------------------------------------
File      : EX1606.c
Purpose   : DS1820 Library
Compiler  : CodeVisionAVR
Target    : ATmega128      
Ref       : CVAVR Examples DS1820 
------------------------------------------*/

//----------------------------------------:INCLUDE

#include <mega128.h>

// 1 Wire Bus functions
#asm
   .equ __w1_port=0x1B ;PORTA
   .equ __w1_bit=0
#endasm
#include <1wire.h>

// DS1820 Temperature Sensor functions
#include <ds1820.h>

// Standard Input/Output functions
#include <stdio.h>
      
#include <delay.h>

/* maximum number of DS1820/DS18S20 connected to the 1 Wire bus */
#define MAX_DEVICES 8

/* DS1820/DS18S20 devices ROM code storage area */
unsigned char rom_code[MAX_DEVICES][9];


//----------------------------------------:MAIN

void main(void)
{   
  unsigned char i,j, devices=0;
  int temp;

  // USART0 initialization
  // Communication Parameters: 8 Data, 1 Stop, No Parity
  // USART0 Receiver: On
  // USART0 Transmitter: On
  // USART0 Mode: Asynchronous
  // USART0 Baud Rate: 9600
  UCSR0A=0x00;
  UCSR0B=0x18;
  UCSR0C=0x06;
  UBRR0H=0x00;
  UBRR0L=0x67;

/* detect how many DS1820/DS18S20 devices
   are connected to the 1 Wire bus */
  devices=w1_search(0xf0,rom_code);

  /* display the ROM codes for each device */
  if (devices ==0) {  
    printf("\f\rno devices were found");
    while (1); /* stop here if no devices were found */
  }
    
  while (1)
  {                                 
    for (i=0;i<devices;) {
      temp=ds1820_temperature_10(&rom_code[i][0]);
      j='+';
      if (temp<0) {
        j='-';
        temp=-temp;
      };                                                   
      printf("\f\rDS1820 Temperature\n\r");
      printf("T%u=%c%i.%u C",++i,j,temp/10,temp%10);      
      delay_ms(800);
    }
  }
}
